<?PHP 
//include ('Service.php');
date_default_timezone_set('UTC');
$tmp1 = new DateTime();

//$tmp1 = $tmp1->modify('+' . 1 . ' month');

print_r('<br />');

print_r($tmp1->format('w m-d'));

print_r('<br />');
print_r( date("w", strtotime($tmp1->format('Y-m-d H:i:s'))  ));
print_r('<br />');
print_r('+2 day');
print_r('<br />');
if (date("w", strtotime($tmp1->format('Y-m-d H:i:s') ) ) == 5 )
{
    $tmp1->modify('+' . 2 . ' day');
}
print_r( date("w", strtotime($tmp1->format('Y-m-d H:i:s'))  ));
print_r('<br />');print_r('<br />');
$tmp1 = $tmp1->format('Y-m-d H:i:s');
$end = $tmp1;



