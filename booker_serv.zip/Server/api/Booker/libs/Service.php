<?PHP
///////////////////////////
//shop      methods///
/////////////////////////// 

include ('DB.php');
include ('Users.php');
class Service extends Users
{
    protected $dbObj;
    protected $pdo;

    function __construct()
    {
        $this->db = new DB;
        $this->pdo = DB::connect();
    }

    function getMd5($p = '')
	{
        if (is_array($p))
            $p = $p[0];
        if (strlen($p) < 1 || $p == 'Md5')
            return 'Please enter yo string';
        return md5($p);
	}
	
    function getHelp($id = false)
    {
        $res = get_class_methods($this);
        return $res;
    }

    function strValid($str)
    {
        $str = htmlspecialchars(trim($str));
        if (strlen($str)<1)
        return false;
        return $str;
    }

    function putAddEvent($params)
    {

      //проверим токен
      if (isset($params['token']))
      {
          $res = $this->putisAuth(['token'=>$params['token']]);
          if (isset($res['auth']) && $res['auth'] == 1)
          $aut['auth'] = $res['auth'];
      } else {
          $aut['auth'] = 0;
      }
      if ($aut['auth'] == 0)
      return ['404'=>'not autorize asses'];

        if (empty($params['user_id']) || empty($params['room_id']))
        return ['404'=>'no user_id or room_id'];
        if (empty($params['years']))
        return ['404'=>'no  year'];
        if (! isset($params['recurring']))
        return ['404'=>'no  recurring'];
        if (empty($params['monthes']) || empty($params['datas']))
        return ['404'=>'no month or day'];
        if (empty($params['hourses_start']) || empty($params['hourses_end']))
        return ['404'=>'no hourses_start or hourses_end'];
        if (empty($params['minutes_start']) || empty($params['minutes_end']))
        return ['404'=>'no minutes_start or minutes_end'];

        $token = $params['token'];
        $name = $params['name'];
        $user_id = $params['user_id'];
        $room_id = $params['room_id'];
        $recurring = $params['recurring'];
        $recurring_spec = $params['recurring_spec'];
        $desc = $this->strValid($params['description']);

        //DATA TIMEs
        $year = $params['years'];
        $mon = $params['monthes'];
        if (strlen($mon) == 1)
        $mon = '0'.$mon;
        $day = $params['datas'];
        if (strlen($day) == 1)
        $day = '0'.$day;
        $hrStart = $params['hourses_start'];
        $minStart = $params['minutes_start'];
        $hrEnd = $params['hourses_end'];
        $minEnd = $params['minutes_end'];
        date_default_timezone_set('UTC');
        //"$d $M $y $h:$m:$s $z"
        $d = new DateTime("$day-$mon-$year $hrStart:$minStart:00");
        $t = strtotime($d->format('Y-m-d H:i:s'));
        $startTimeStamp = $t;
        $d = new DateTime("$day-$mon-$year $hrEnd:$minEnd:00");
        $t = strtotime($d->format('Y-m-d H:i:s'));
        $endTimeStamp = $t;
        $time = time();
        
        $q = "select count(*) from b_events " . 
        "where room_id = $room_id " .
        "and ($startTimeStamp >= start_time and $endTimeStamp <= end_time) ";

        if (is_object($this->pdo))
        {
            $stmt = $this->pdo->prepare($q);
            $stmt->execute();
            $r = $stmt->fetchAll();
        }

        if (! is_array($r))
        return ['404'=>'query error'];
        if (is_array($r) && $r[0]['count(*)'] > 0)
        return ['a'=>'time is busy'];
        
        $recurring = 0; //debug
            if (0 == $recurring)
            $recurent_id = 0;

            // создать рекурентные события если выбрано !!!!!!!!!!!!!!!!!!!

            $q="INSERT INTO " .
            "b_events(user_id,created,start_time,end_time,room_id,recurent_id,description) " .
            "VALUES ($user_id,$time,$startTimeStamp,$endTimeStamp,$room_id,$recurent_id,'$desc')";
            return ['OKss'=>$q];
            $stmt = $this->pdo->prepare($q);
            $stmt->execute();
            if ($stmt)
            {
              return ['OK'=>'200'];
            }
            return ['Error'=>'500'];
    }

    function getShowCars($params = false)
    {
        $aut['auth'] = 0;
        //проверим токен
        if (isset($params['token']))
        {
            $res = $this->putisAuth(['token'=>$params['token']]);
            if (isset($res['auth']) && $res['auth'] == 1)
            $aut['auth'] = $res['auth'];
        } else {
            $aut['auth'] = 0;
        }

        if ($aut['auth'] == 0)
        return ['auth'=>0];


        
        if (isset($params[0]))
        $id = $params[0];
        if (isset($params['id']))
        $id = $params['id'];
        if (is_numeric($id) && $id > 0)
        {
            $id = (integer)$id;
            //$q = "select * from cars where id='$id'"; //test variant query
          $q = 'SELECT cars.model model,cars.id id,cars.year,engines.value engine,colors.color,cars.maxspeed speed,cars.price 
          FROM cars,colors,engines 
          WHERE engine_id = engines.id and colors.id = color_id and cars.id =' . $id;
        } 
        else 
        {
          $q  = 'SELECT cars.id id,cars.model,cars.year FROM cars,brands ';
          $q .= 'WHERE brands.id = brand_id';
        }
        
        if (is_object($this->pdo))
        {
            $stmt = $this->pdo->prepare($q);
            $stmt->execute();
            $res = $stmt->fetchAll();
        }
        return $res;
    }

    function postOrderShow($params)
    {
      //return ['orderShowTest'=>$params];


      $email = '';
      $token = $params['token'];
      $email = $params['user_id'];

      //проверим токен
      if (isset($params['token']))
      {
          $res = $this->putisAuth(['token'=>$params['token']]);
          if (isset($res['auth']) && $res['auth'] == 1)
          $aut['auth'] = $res['auth'];
      } else {
          $aut['auth'] = 0;
      }

      if ($aut['auth'] == 0)
      return ['404'=>'asses denied'];

      //спросим ордер юзера
      $q = "SELECT cars.model model, cars.price price, orders.date date, orders.count 
      FROM cars, orders, users WHERE
      (users.id=orders.user_id AND orders.car_id=cars.id) AND users.email='$email'";

      if (is_object($this->pdo))
        {
            $stmt = $this->pdo->prepare($q);
            $stmt->execute();
            $res = $stmt->fetchAll();
        }

        if (is_array($res) && count($res) > 0)
        return $res;
        return ['Error'=>'302'];
    }
}