<?PHP
///////////////////////////
//shop      methods///
/////////////////////////// 

include ('DB.php');
include ('Users.php');
class Service extends Users
{
    protected $dbObj;
    protected $pdo;

    function __construct()
    {
        $this->db = new DB;
        $this->pdo = DB::connect();
    }

    function getMd5($p = '')
	{
        if (is_array($p))
            $p = $p[0];
        if (strlen($p) < 1 || $p == 'Md5')
            return 'Please enter yo string';
        return md5($p);
	}
	
    function getHelp($id = false)
    {
        $res = get_class_methods($this);
        return $res;
    }

    function strValid($str)
    {
        $str = htmlspecialchars(trim($str));
        if (strlen($str)<1)
        return false;
        return $str;
    }

   
}