<template>

 <div class="container">
    <div class="col-md-4">
    <header>
      <h3>
      Welcome
      </h3>
    </header>

      <transition name="fade">
        <div class="alert alert-success" v-if="filterDate != undefined"> Date selected is: {{formattedDate}}</div>
      </transition>
      <div class="table-responsive">
        <table class="table table-bordered">
          <thead class="thead-default">
		  
            <tr>
              <th colspan="1">
                <a href="#" class="prev" @click="previousMonth"><</a>
              </th>
              <th colspan="5" class="center-title">
                {{currentMonthAndYear}}
              </th>
              <th colspan="1">
                <a href="#" class="next" @click="nextMonth">></a>
              </th>
            </tr>
			
            <tr v-if="this.weekStart == 6">
              <th v-for="d in weekM">{{d}}</th>
            </tr>
            <tr v-else>
              <th v-for="d in weekS">{{d}}</th>
            </tr>
          </thead>
		  
          <tbody class="tbody-default" data-bind="foreach:gridArray">
            <tr v-for="item in gridArray">
      
              <td :class="{'red':isWeekend(data.d)}" v-for="data in item">
                
			          <span  v-if="data.d.getMonth() == selectedDate.getMonth() && isWeekend(data.d)">
                  <a href="#"  >
                    {{data.d.getDate()}}
                  </a>
			          </span>

                <span  v-if="data.d.getMonth() == selectedDate.getMonth() && !isWeekend(data.d)">
                  <a href="#" @click="setDate(data.d)" :class="{'cal-selected':isActive(data.d)}"  >
                    {{data.d.getDate()}}<br />
                    {{data.e.description}}
                      <!--
                      <div v-if="data.e[0].room_id > 0">room {{data.e[0].room_id}}</div>
                      -->
                  </a>
			          </span>

                <span class="nocurrmonth" v-if="data.d.getMonth() != selectedDate.getMonth()">
                    <a href="#" >
                      {{data.d.getDate()}}
                    </a>
                </span>
              </td>
            </tr>

          </tbody>
        </table>
      </div>

    </div>
      <div class="rms">
            Boardroom 1 <input type="radio" class="first_room" v-model="userData.boardroom" checked value="1" @change="selectRoom()"><br />
            Boardroom 2 <input type="radio" v-model="userData.boardroom" value="2" @change="selectRoom()" ><br />
            Boardroom 3 <input type="radio" v-model="userData.boardroom" value="3" @change="selectRoom()" ><br />
      </div>
    <div class="right_elems">
  
 
        <div class="login">
          <form action="" class="login_form">
            login:<br />
            <input type="text" v-model="email" placeholder="email"><br />
            password:<br />
            <input type="password" v-model="password"><br />
            password confirm:<br />
            <input type="password" v-model="passwordconfirm"><br />
            <button id="login_button" @click="putLogin()">Login</button>
          </form>
        </div>
    </div>

  <div class="switch">
    <input @click="switchFirstDay()" v-model="switcher" type="checkbox">
    <label><i></i></label>
  </div>

</div>


</template>

<script>
import $ from 'jquery';
export default {
  name: 'calendar',
  data () {
			return{
            monthEventsList: [
              {
              date: new Date(),
              start: 'start date',
              end: 'end date',
              description: 'This is 1',
              recorent: 'no',
              room_id: '1'
              },
              {
              date: new Date(),
              start: 'start date',
              end: 'end date',
              description: 'Hello dude 2',
              recorent: 'no',
              room_id: '2'
              },
              {
              date: new Date(),
              start: 'start date',
              end: 'end date',
              description: 'Room 3',
              recorent: 'no',
              room_id: '3'
              },
            ],
            url2:'http://tc.geeksforless.net/~user11/test/Client/api/test',
            url:'http://127.0.0.1/test/Client/api/',
            weekM:['M','T','W','T','F','S','S'],
            weekS:['S','M','T','W','T','F','S'],
            list: '',
            switcher: '',
            weekStart: localStorage.getItem('weekStart') || 6, // 6 - from mondey, 0 - from sand
            islogin:false,
            token: localStorage.getItem('token') || '',
            password: '',
            email: localStorage.getItem('email') || '',
            passwordconfirm: '',
						filterDate: undefined,
						selectedDate: new Date(),	
						curMon:this.mnn(),
						curYear:this.yearnow(),
						currentMonthAndYear: this.getMonth(this.curMon)+' '+this.curYear,	
            userData: JSON.parse(localStorage.getItem('uData')) || {},
			}

  },

  beforeMount() {
    if (this.userData.boardroom == undefined){
      this.userData.boardroom = 1;
      } else {
    }
    this.userData.password = '';
    this.userData.passwordconfirm = '';
  },
  
  methods: {

  switchFirstDay() {
    var ch = this.switcher;
    if (!ch)
    {
      this.weekStart = 0;
    }else {
      this.weekStart = 6;
    }

    this.save();
  },

  save() {
    localStorage.setItem('uData', JSON.stringify(this.userData));
    localStorage.setItem('uToken', this.token || '');
    localStorage.setItem('islogin', this.islogin || 0);
    localStorage.setItem('email', this.email || '');
    localStorage.setItem('weekStart', this.weekStart || 6);
  },

  selectRoom(){
    this.event = 'event for '+this.userData.boardroom;
    this.monthEventsList.description = 'room ' + this.userData.boardroom;
  },


	getMonth(n) {
	var monthsz =  ['Yan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Now','Dec'];
	return monthsz[n];
	},
	
	yearnow() {
		this.curYear = (new Date()).getFullYear();
		return (new Date()).getFullYear();
	},
	mnn() {
		this.curMon = (new Date()).getMonth();
		return (new Date()).getMonth();
	},
	
    previousMonth: function() {
      var tmpDate = this.selectedDate;
      var tmpMonth = tmpDate.getMonth() - 1;
	  this.selectedDate = new Date(tmpDate.setMonth(tmpMonth));
	  this.selectedDate.setMonth(tmpMonth);
	  this.currentMonthAndYear = this.getMonth(this.selectedDate.getMonth())+' '+this.selectedDate.getFullYear();
    },
	
    nextMonth: function() {
      var tmpDate = this.selectedDate;
      var tmpMonth = tmpDate.getMonth() + 1;
	  this.selectedDate = new Date(tmpDate.setMonth(tmpMonth));
	  this.currentMonthAndYear = this.getMonth(this.selectedDate.getMonth())+' '+this.selectedDate.getFullYear();
	},
	
    setDate: function(date) {
      if (date == this.filterDate) {
        this.filterDate = undefined;
      } else {
        var test = [];
        this.putTest(test);
        this.filterDate = date;
      }
    },
/////GET/////
    getTest: function() {
      this.$http.get(this.url)
      .then(response => {
        var res = JSON.stringify(response.data);
        this.list = JSON.parse(res || {});
        console.log(this.list.test);
      })
      .catch(error => {
        console.log(error);
      });
    },
/////POST/////
    postTest: function(params) {
      this.$http.post(this.url,{f_nia:"delow"}
      , {
          headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
          }
      }
      )
      .then(response => {
        var res = JSON.stringify(response.data);
        this.list = JSON.parse(res || {});
        console.log(this.list);
      })
      .catch(error => {
        console.log(error);
      });
    },
	/////PUT/////
    putLogin: function() {
      this.save();
      //console.log();
      alert(this.email);
      this.$http.put(this.url+'Login',{
        email:this.email,
        password:this.password,
        passwordconfirm:this.passwordconfirm,
        }, 
        {
          headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
          }
        }
      )
      .then(response => {
        var res = JSON.stringify(response.data);
        this.list = JSON.parse(res || '[]');
        console.log(this.list);
      })
      .catch(error => {
        console.log(error);
      });
    },
/////PUT/////
    putTest: function(params) {
      this.$http.put(this.url,{goonia:"delow"},{
          headers:{
                'Accept': 'application/json',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                }
      }
      )
      .then(response => {
        var res = JSON.stringify(response.data);
        this.list = JSON.parse(res || '[]');
        console.log(this.list);
      })
      .catch(error => {
        console.log(error);
      });
    },

    isActive: function(date) {
      return date === this.filterDate;
    },
  
	  isWeekend: function(date) {
      if (this.weekStart == 6){
        return ((date.getDay() == 0) || (date.getDay() == 6));
        
      } 
        return ((date.getDay() == 5) || (date.getDay() == 6));
    },
	
    //фомируем месяц от входящей даты
    getCalendarMatrix: function(date) {
      var calendarMatrix = [];
      var eventMatrix = [];
      var startDay = new Date(date.getFullYear(), date.getMonth(), 1);
      var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);

      if (this.weekStart == 6){
        this.weekStart = 6;
      }else{
        this.weekStart = 0;
      }
      // Modify the result of getDay so that we treat Monday = 0 instead of Sunday = 0
      var startDow = (startDay.getDay() + this.weekStart) % 7;
      var endDow = (lastDay.getDay() + 6) % 7;

      // If the month didn't start on a Monday, start from the last Monday of the previous month
      startDay.setDate(startDay.getDate() - startDow);

      // If the month didn't end on a Sunday, end on the following Sunday in the next month
      lastDay.setDate(lastDay.getDate() + (6 - endDow));

      //this.monthEventsList = getAllEventsForMons(data); ///array
      
      
      var week = [];
      while (startDay <= lastDay) {
  

        // console.log(this.monthEventsList);

        // for (var i = 0; i < this.monthEventsList.length; i++) {
        //   //if (this.monthEventsList[i].length > 0)
        //   // $event.push(this.monthEventsList[i]);
        // }
        var $event = [];
        var room = this.userData.boardroom;
        this.monthEventsList.forEach(function(item, i, arr) {
          if (item.room_id == room && startDay.getDate() == item.date.getDate() )
          {
            $event = item;
          }
          
        });

        //$event = this.monthEventsList[0];
        // console.log(this.monthEventsList);
        // console.log($event);

        //$event = this.monthEventsList[0];

        
        week.push({d:new Date(startDay),e: $event}); //пушим событие к дате
        if (week.length === 7) {
          calendarMatrix.push(week);
          week = [];
        }
        startDay.setDate(startDay.getDate() + 1)
      }
      //console.log(calendarMatrix);
      return calendarMatrix;
    },
  },
  computed: {
    // получим месяц
    gridArray: function() {
      var grid = this.getCalendarMatrix(this.selectedDate);
      return grid;
    },
	
	formattedDate: function() {
      return this.filterDate.getDate() + '  '+
	  this.getMonth((this.filterDate.getMonth()+1)) + ' of ' +
		this.filterDate.getFullYear();
    }
	
  },

  watch: {
    userData: function (val) {
      this.save();
    },
  }

}


</script>


<style scoped>
.switch {
    width: 180px;
    height: 50px;
    position: relative;
}
.switch label {
    display: block;
    width: 100%;
    height: 100%;
    position: relative;
    background: #a5a39d;
    border-radius: 40px;
    box-shadow:
        inset 0 3px 8px 1px rgba(0,0,0,0.2),
        0 1px 0 rgba(255,255,255,0.5);
}
.switch label:after {
    content: "";
    position: absolute;
    z-index: -1;
    top: -8px; right: -8px; bottom: -8px; left: -8px;
    border-radius: inherit;
    background: #ccc; /* Fallback */
    background: linear-gradient(#f2f2f2, #ababab);
    box-shadow: 0 0 10px rgba(0,0,0,0.3),
        0 1px 1px rgba(0,0,0,0.25);
}
.switch label:before {
    content: "";
    position: absolute;
    z-index: -1;
    top: -18px; right: -18px; bottom: -18px; left: -18px;
    border-radius: inherit;
    background: #eee; /* Fallback */
    background: linear-gradient(#e5e7e6, #eee);
    box-shadow: 0 1px 0 rgba(255,255,255,0.5);
    -webkit-filter: blur(1px); /* Smooth trick */
    filter: blur(1px); /* Future-proof */
}
.switch label i {
    display: block;
    height: 100%;
    width: 60%;
    position: absolute;
    left: 0;
    top: 0;
    z-index: 2;
    border-radius: inherit;
    background: #b2ac9e; /* Fallback */
    background: linear-gradient(#f7f2f6, #b2ac9e);
    box-shadow:
        inset 0 1px 0 white,
        0 0 8px rgba(0,0,0,0.3),
        0 5px 5px rgba(0,0,0,0.2);
}
.switch label i:after {
    content: "";
    position: absolute;
    left: 15%;
    top: 25%;
    width: 70%;
    height: 50%;
    background: #d2cbc3; /* Fallback */
    background: linear-gradient(#cbc7bc, #d2cbc3);
    border-radius: inherit;
}
.switch label i:before {
    content: "MON";
    position: absolute;
    top: 50%;
    right: -50%;
    margin-top: -12px;
    color: #666; /* Fallback */
    color: rgba(0,0,0,0.4);
    font-style: normal;
    font-weight: bold;
    font-family: Helvetica, Arial, sans-serif;
    font-size: 24px;
    text-transform: uppercase;
    text-shadow: 0 1px 0 #bcb8ae, 0 -1px 0 #97958e;
}

.switch input:checked ~ label { /* Background */
    background: #9abb82;
}
 
.switch input:checked ~ label i { /* Toggle */
    left: auto;
    right: -1%;
}
 
.switch input:checked ~ label i:before { /* On/off */
    content: "SAN";
    right: 115%;
    color: #82a06a;
    text-shadow: 0 1px 0 #afcb9b, 0 -1px 0 #6b8659;
}




.right_elems {
  display:inline-block;
  position:absolute;
  top:195px;
  right:1px;
  padding-bottom:0px;
  background:linear-gradient(rgba(185, 181, 173, 0.8),rgba(100,110,100,.8));
  border:1px solid green;
  border-radius:3px;
  padding:5px;
  margin-top:15px;
  margin:0 auto;
  
}

.login {
  color:#fff;
  text-shadow: 0 0 4px #000;
  font-family:'Times New Roman', Times, serif;
  width:200px;
  top:200px;
  right:10px;
  border:1px solid gray;
  border-radius:3px;
  padding:0 2px;
  float:left;
  background:rgba(0,0,0,.2);
  margin: auto;
  box-shadow:0px -1px 9px #000;
}

.login input{
  border-radius: 8px;
  width: 190px;
  background:rgb(10,110,255);
  color:rgb(159, 162, 163);
  text-shadow:0 -1px 1px#800;
  font-family:monospace;
  font-weight: 600;
  border:none;
  box-shadow: -1px 0 0 0,1px 0 0 0;
}
.login button{
  border-radius: 8px;
  width: 190px;
  background:rgb(255, 255, 255);
  color:#000;
  font-weight: 600;
  border:none;
  box-shadow: -1px 0 0 0,1px 0 0 0;
  margin-top: 5px;
  cursor:pointer;
}
.login button:hover{
  background:rgb(250, 200, 0);
}

.rms {
  position:absolute;
  top:100px;
  right:4px;
  background:linear-gradient(rgba(0,0,0,.3),rgba(0,0,0,.7));
  width:210px;
  color:#fff;
  border:1px solid gray;
  border-radius:3px;
  float:right;
  text-align:left;
  box-shadow:2px 2px 6px #000;
}
.table-bordered{
background:linear-gradient(#aaa,#aaa);
box-shadow:2px 3px 7px #888;
border-radius:5px;
width:70%;
}

.red {
background:linear-gradient(#d25,#f47);
color:#fff;
}
.red a{color:#fff;}

.fade-enter-active,
.fade-leave-active {
  transition: opacity .5s
}

.fade-enter,
.fade-leave-active {
  opacity: .3
  
}

.thead-default, .thead-default a {
  background:linear-gradient(#0ac,#0bc,#0bc,#ccc);
  color:#fff;
}

.tbody-default{
  background:linear-gradient(#ccc);
}

.tbody-default td{
  height:35px;
  }

a {
  padding: 0px 10px 0px 10px;
}

.center-title {
  text-align: center;

}

a.cal-selected,
a.cal-selected:focus {
  background-color: #368CB2;
  color: #fff;
  border-radius: 8px;
  font-weight: bold;
  box-shadow:2px 2px 4px #000;
  /*font-size: 1.8em*/
}
.nocurrmonth a {
color:#aaa;
text-decoration:none;
}
</style>
