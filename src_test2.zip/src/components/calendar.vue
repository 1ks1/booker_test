<template>

 <div class="container">
    <div class="col-md-4">
      <h3>
      Booker
      </h3>
    <div class="rms">
      Boardroom 1 <input type="radio" v-model="boardroom" checked value="1" @change="selectRoom()"><br />
      Boardroom 2 <input type="radio" v-model="boardroom" value="2" @change="selectRoom()" ><br />
      Boardroom 3 <input type="radio" v-model="boardroom" value="3" @change="selectRoom()" ><br />
    </div>
      <transition name="fade">
        <div class="alert alert-success" v-if="filterDate != undefined"> Date selected is: {{formattedDate}}</div>
      </transition>
      <div class="table-responsive">
        <table class="table table-bordered">
          <thead class="thead-default">
		  
            <tr>
              <th colspan="1">
                <a href="#" class="prev" @click="previousMonth"><</a>
              </th>
              <th colspan="5" class="center-title">
                {{currentMonthAndYear}}
              </th>
              <th colspan="1">
                <a href="#" class="next" @click="nextMonth">></a>
              </th>
            </tr>
			
            <tr>
              <th>M</th>
              <th>T</th>
              <th>W</th>
              <th>T</th>
              <th>F</th>
              <th>S</th>
              <th>S</th>
            </tr>
          </thead>
		  
          <tbody class="tbody-default" data-bind="foreach:gridArray">
            <tr v-for="item in gridArray">
      
              <td :class="{'red':isWeekend(data.d)}" v-for="data in item">
                
			          <span  v-if="data.d.getMonth() == selectedDate.getMonth() && isWeekend(data.d)">
                  <a href="#"  >
                    {{data.d.getDate()}}
                  </a>
			          </span>

                <span  v-if="data.d.getMonth() == selectedDate.getMonth() && !isWeekend(data.d)">
                  <a href="#" @click="setDate(data.d)" :class="{'cal-selected':isActive(data.d)}"  >
                    {{data.d.getDate()}}<br />{{data.e}}
                  </a>
			          </span>

                <span class="nocurrmonth" v-if="data.d.getMonth() != selectedDate.getMonth()">
                    <a href="#" >
                      {{data.d.getDate()}}
                    </a>
                </span>
              </td>
            </tr>

          </tbody>
        </table>
      </div>

    </div>

</div>

</template>

<script>
export default {
  name: 'calendar',
  
  data () {
			return{
            monthEventsList: {
              data: new Date(),
              description: 'This is event'
            },
            event: 'event ',
            boardroom: 1,
						filterDate: undefined,
						selectedDate: new Date(),	
						curMon:this.mnn(),
						curYear:this.yearnow(),
						currentMonthAndYear: this.getMonth(this.curMon)+' '+this.curYear,	
			}

  },
  
  methods: {

  selectRoom(){
    this.event = 'event for '+this.boardroom;
    this.monthEventsList.description = 'room ' + this.boardroom;
    console.log(this.boardroom); ///check ROOM
    
  },

	getMonth(n) {
	var monthsz =  ['Yan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Now','Dec'];
	return monthsz[n];
	},
	
	yearnow() {
		this.curYear = (new Date()).getFullYear();
		return (new Date()).getFullYear();
	},
	mnn() {
		this.curMon = (new Date()).getMonth();
		return (new Date()).getMonth();
	},
	
    previousMonth: function() {
      var tmpDate = this.selectedDate;
      var tmpMonth = tmpDate.getMonth() - 1;
	  this.selectedDate = new Date(tmpDate.setMonth(tmpMonth));
	  this.selectedDate.setMonth(tmpMonth);
	  //console.log(tmpDate.getFullYear());
	  //console.log(this.selectedDate.getMonth());
	  this.currentMonthAndYear = this.getMonth(this.selectedDate.getMonth())+' '+this.selectedDate.getFullYear();
    },
	
    nextMonth: function() {
      var tmpDate = this.selectedDate;
      var tmpMonth = tmpDate.getMonth() + 1;
	  this.selectedDate = new Date(tmpDate.setMonth(tmpMonth));
	  
	  //console.log(tmpDate.getFullYear());
	  //console.log(this.selectedDate.getMonth());
	  this.currentMonthAndYear = this.getMonth(this.selectedDate.getMonth())+' '+this.selectedDate.getFullYear();
	},
	
	
	
    setDate: function(date) {
	  //console.log(date);
      if (date == this.filterDate) {
        console.log('setting undefined');
        this.filterDate = undefined;
        //unselected
      } else {
        this.filterDate = date;
      }
    },
	
	
    isActive: function(date) {
      return date === this.filterDate;
    },
	
	  isWeekend: function(date) {
      return ((date.getDay() == 0) || (date.getDay() == 6));
    },
	
    //фомируем месяц от входящей даты
    getCalendarMatrix: function(date) {
      var calendarMatrix = [];
      var eventMatrix = [];
      var startDay = new Date(date.getFullYear(), date.getMonth(), 1);
      var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);

      // Modify the result of getDay so that we treat Monday = 0 instead of Sunday = 0
      var startDow = (startDay.getDay() + 6) % 7;
      var endDow = (lastDay.getDay() + 6) % 7;

      // If the month didn't start on a Monday, start from the last Monday of the previous month
      startDay.setDate(startDay.getDate() - startDow);

      // If the month didn't end on a Sunday, end on the following Sunday in the next month
      lastDay.setDate(lastDay.getDate() + (6 - endDow));
      var event = this.event;
      var week = [];
      while (startDay <= lastDay) {
        console.log(this.monthEventsList.data.getDate());
        console.log(startDay.getDate());
        if(this.monthEventsList.data.getDate() === startDay.getDate()){
          event = this.monthEventsList.description;
        }else {
          event = '';
        }
        week.push({d:new Date(startDay),e: event}); //пушим событие к дате

        if (week.length === 7) {
          calendarMatrix.push(week);
          week = [];
        }
        startDay.setDate(startDay.getDate() + 1)
      }
      console.log(calendarMatrix);
      return calendarMatrix;
    }
  },
  computed: {
    // получим месяц
    gridArray: function() {
      var grid = this.getCalendarMatrix(this.selectedDate);
      return grid;
    },
	
	formattedDate: function() {
      return this.filterDate.getDate() + '  '+
	  this.getMonth((this.filterDate.getMonth()+1)) + ' of ' +
		this.filterDate.getFullYear();
    }
	
  }  

}


</script>


<style scoped>


.rms {
  background:#ccc;
  width:25%;
  border:1px solid red;
  border-radius:3px;
  float:right;
  text-align:left;
}
.table-bordered{
background:linear-gradient(#aaa,#aaa);
box-shadow:2px 3px 7px #888;
border-radius:5px;
width:70%;
}

.red {
background:linear-gradient(#d25,#f47);
color:#fff;
}
.red a{color:#fff;}

.fade-enter-active,
.fade-leave-active {
  transition: opacity .5s
}

.fade-enter,
.fade-leave-active {
  opacity: .3
  
}

.thead-default, .thead-default a {
  background:linear-gradient(#0ac,#0bc,#0bc,#ccc);
  color:#fff;
}

.tbody-default{
  background:linear-gradient(#ccc);
}

.tbody-default td{
  height:35px;
  }

a {
  padding: 0px 10px 0px 10px;
}

.center-title {
  text-align: center;

}

a.cal-selected,
a.cal-selected:focus {
  background-color: #368CB2;
  color: #fff;
  border-radius: 8px;
  font-weight: bold;
  box-shadow:2px 2px 4px #000;
  /*font-size: 1.8em*/
}
.nocurrmonth a {
color:#aaa;
text-decoration:none;
}
</style>
