<template>

  <div class="test">
  <h1>USERS</h1>
  <router-link to="/" exact>home</router-link>

  <div class="u-name">Hello {{userData.name}}</div>
  <ul class="js-main-buttons">
  <li><button @click="getUsers()">Get Users</button></li>
  </ul>
  {{usersList}}


      <div class="user-list" v-if="usersList.length > 0">
        <table>
          <tr>
            <td>id</td><td>name</td><td>lastname</td><td>email</td><td>role</td><td>action</td>
          </tr>

          <tr v-for="(item, index) in usersList" :key="index">
            <td>{{item.id}}</td>
            <td>{{item.name}}</td>
            <td>{{item.lastname}}</td>
            <td><a :href="'mailto:'+item.email">{{item.email}}</a></td>
            <td>{{item.role}}</td>
            <td><button v-on:click="editUser(item)">EDIT</button></td>
          </tr>
        </table>
      </div>

      <div v-else class="user-list">
        u r not admin. sorry
      </div>

      <br />
      <div class="js_edit_user">
        <div v-if="user !== undefined">
            <input type="text" v-model="user.name" /> - name<br />
            <input type="text" v-model="user.lastname" /> - lastname<br />
            <input type="text" v-model="user.email" /> - email<br />
            <input type="text" v-model="user.password" /> - password<br />
            <input type="text" v-model="user.role" /> - role<br />
            <input type="text" v-model="user.status" /> - status<br />
            <button @click="saveUser(user)">Save</button>
        </div>
      </div>

  </div>

</template>

<script>
import $ from 'jquery';
import { constants } from 'os';
export default {
  name: 'test',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App',
      url:'http://tc.geeksforless.net/~user11/test/Client/api/',

      userData: JSON.parse(localStorage.getItem('uData')) || {
              token:'',
              email:'',
              boardroom: 1,
              logstat: 0,
              password: '',
              name:''
            },
      usersList:'',
      editableUser:{},
      user: JSON.parse(localStorage.getItem('editUser')) || undefined
    } 
  },

  methods: {

    saveUser(user) {

      var userDataObj = {
            room_id:this.userData.boardroom,
            token: this.userData.token,
            email: this.userData.email,
            user_id: this.userData.user_id,
            userEdit:user
      };

      $.ajax({
              url: this.url+'saveUser/',
              type: 'put',
              dataType: 'json',
              data: userDataObj,

              success: response => {
                  //result = $.parseJSON(response);
                  console.log(response);
                  this.user = response;
              },

              error: function(response) { 
                console.log('Err');
                console.log(response);
              }
      });

    },

    editUser(item) {
        var userDataObj = {
          room_id:this.userData.boardroom,
          token: this.userData.token,
          email: this.userData.email,
          user_id: this.userData.user_id,
          editableUid:item.id,
        };
      
        $.ajax({
            url: this.url+'UserEdit/',
            type: 'POST',
            dataType: 'json',
            data: userDataObj,

            success: response => {
                //result = $.parseJSON(response);
                console.log(response);
                this.user = response;
            },

            error: function(response) { 
              console.log('Err');
              console.log(response);
            }

        });
    },

    getUsers: function(){
      var userDataObj = {
          room_id:this.userData.boardroom,
          token: this.userData.token,
          email: this.userData.email,
          user_id: this.userData.user_id,
        };
      
        $.ajax({

            url: this.url+'Users/',
            type: 'POST',
            dataType: 'json',
            data: userDataObj,

            success: response => {
                //result = $.parseJSON(response);
                console.log(response);
                this.usersList = response;
            },

            error: function(response) { 
              console.log('Err');
              console.log(response);
            }
        });
      console.log(this.usersList);
      return false;
    }
  }
}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.user-list table{
  border:1px solid gray;
  border-collapse: collapse;
}
.user-list td{
  border: 1px solid black; 
}
.js_edit_user{
  text-align:left;
}

</style>
