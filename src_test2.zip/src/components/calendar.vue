<template>

 <div class="container">
    <div class="col-md-4">
    <header>
      <h3>
      Welcome
      </h3>
    </header>

    <div id="logout" @click="logout()" :class="{'login_status':userData.logstat == 1,'logout_status':userData.logstat == 0}">
       {{userData.name}}
    </div>

    <div id="result_form"></div>
    <br />
    <div id="result_form"></div>
    <br />
      <transition name="fade">
        <div class="alert alert-success" v-if="filterDate != undefined"> Date selected is: {{formattedDate}}</div>
      </transition>
      <div class="table-responsive">
        <table class="table table-bordered" :class="{'hidden_elem':userData.logstat !== 1}">
          <thead class="thead-default">
		  
            <tr>
              <th colspan="1">
                <a href="#" class="prev" @click="previousMonth">&#8656;</a>
              </th>
              <th colspan="5" class="center-title">
                {{currentMonthAndYear}}
              </th>
              <th colspan="1">
                <a href="#" class="next" @click="nextMonth">&#8658;</a>
              </th>
            </tr>
			
            <tr v-if="this.weekStart == 6">
              <th v-for="(d,index) in weekM" :key="index">{{d}}</th>
            </tr>
            <tr v-else>
              <th v-for="(d,index) in weekS" :key="index">{{d}}</th>
            </tr>
          </thead>
		  
          <tbody class="tbody-default" data-bind="foreach:gridArray">
            <tr v-for="(item,index) in gridArray" :key="index">
      
              <td :class="{'red':isWeekend(data.d),'cal-selected':isActive(data.d)}" v-for="(data,index) in item" :key="index">
                <!-- вфходной день -->
                  <span  v-if="data.d.getMonth() == selectedDate.getMonth() && isWeekend(data.d)">
                    <a href="#"  >
                      {{data.d.getDate()}}
                    </a>
                  </span>

                  <!-- рабочий день -->
                  <div v-if="data.d.getMonth() == selectedDate.getMonth() && !isWeekend(data.d)">
                    <div>
                        <!-- вывод числа -->
                        <b @click="setDate(data.d)">{{data.d.getDate()}}</b>

                        <!-- вывод события -->
                        <div  class="event_time" v-for="(e,index) in data.e" :key="index" >
                          <span @click="CurrEventClick(data)" :data-id="e.id">{{('0'+e.start_time.getHours()).slice(-2)}}:{{('0'+e.start_time.getUTCMinutes()).slice(-2)}}
                            - {{('0'+e.end_time.getHours()).slice(-2)}}:{{('0'+e.end_time.getUTCMinutes()).slice(-2)}}

                          </span>
                        </div>

                      </div>
                  </div>

                  <!-- день "чужого" месфца -->
                  <span class="nocurrmonth" v-if="data.d.getMonth() != selectedDate.getMonth()">
                      <a href="#" >
                        {{data.d.getDate()}}
                      </a>
                  </span>
        
              </td>
            </tr>

          </tbody>
        </table>
      </div>

    </div>
      <div class="rms" :class="{'hidden_elem':userData.logstat !== 1}">
            Boardroom 1 <input type="radio" class="first_room" v-model="userData.boardroom" checked value="1" @change="selectRoom()"><br />
            Boardroom 2 <input type="radio" v-model="userData.boardroom" value="2" @change="selectRoom()" ><br />
            Boardroom 3 <input type="radio" v-model="userData.boardroom" value="3" @change="selectRoom()" ><br />
        <div>
          <input @click="switchFirstDay()" v-model="switcher" type="checkbox"> first: <b>sunday</b>
          <label><i></i></label>
        </div>
      
      </div>
    <div  :class="{'hidden_elem':userData.logstat == 1,'right_elems':userData.logstat !== 1}">

        <div class="form_user_login login">
          <form action="" class="login_form">
            email:<br />
            <input type="text" v-model="userData.email" name="email" placeholder="email"><br />
            password:<br />
            <input type="password" name="password" v-model="userData.password"><br />
            <button type="button" name="sendLogin" id="btn_login" @click="putLogin()">Login</button>
          </form>
        </div>

          <div class="form_user_registration">
            <form id="registration_form" >
            <p>register</p>
            <input type="text" name="firstname" placeholder="firstname"><br />
            <input type="text" name="lastname" placeholder="lastname"><br />
            <input type="text" name="email" placeholder="email"><br />
            <i>password:</i><br />
            <input type="password" name="password" ><br />
            <i>password confirm:</i><br />
            <input type="password" name="confirmpassword"><br />
            <button name="send" @click="registration()" type="button" id="btn">SEND</button>
            </form>
          </div>          

    </div>

  

  <div :class="{'hidden_elem':putIsAuth() == false}" >
    <form  class="sending_event" id="add_event_form">
    details:<br />
    1. Booked for:<br />

    <select v-model="cEvent.booked_for" class="employees" name="employees_select">
    <option>employees</option>
    <option>dates</option>
    <option>times</option>
    </select><br />
    2. I would like to book this meeting:<br />
    <select class="monthes" name="monthes">
    month
    
    <option v-for="(i,index) in 12" :key="index" :selected="(new Date(cEvent.start_time || selDate).getMonth()+1) == i">{{i}}</option>
    </select>
    
    <select class="datas" name="datas">
    day<option v-for="(i,index) in 31" :key="index" :selected="new Date(cEvent.start_time || selDate).getDate() == i">{{i}}</option>
    </select>
    <select class="years" name="years">
    <option  v-for="(i,index) in 10" :key="index">{{i + new Date(cEvent.start_time || selDate).getFullYear() - 1}}</option>
    </select>
    <br />
    3. Specify what the time and oft he mitting<br />
    <br />
    start:
    <select v-model="cEvent.startH" class="hourses_start" name="hourses_start">
    <option v-for="(i,index) in 24" :key="index" :selected="i-1 == new Date(cEvent.start_time || selDate).getHours() ">{{i -1}}</option>
    </select>
    :
    <select v-model="cEvent.startM" class="minutes_start" name="minutes_start">
    <option v-for="(i,index) in 60" :key="index" :selected="i-1 == new Date(cEvent.start_time || selDate).getMinutes()">{{i-1}}</option>
    </select>
    <br />
    end:
    <select v-model="cEvent.endH" class="hourses_end" name="hourses_end">
    <option v-for="(i,index) in 24" :key="index"  :selected="new Date(cEvent.end_time || selDate).getHours() == i-1">{{i-1}}</option>
    </select> :
    <select v-model="cEvent.endM" class="minutes_end" name="minutes_end">
    <option v-for="(i,index) in 60" :key="index" :selected="new Date(cEvent.end_time || selDate).getMinutes() == i-1">{{i-1}}</option>
    </select><br />
    <br />
    4. description:<br />
    <textarea v-model="cEvent.description" rows="2" cols="30" name="description"></textarea>
    <br />
    5. recurring:<br />
    <input type="checkbox" v-model="cEvent.recurring" name="recurring" /> 
    <b v-if="cEvent.recurring">Yes</b>
    <b v-else>Nop</b>
    <br />
    <div v-if="cEvent.recurring">
        6. weekly, bi-weekly or monthly:<br />
        weekly:<input type="radio" v-model="cEvent.recurring_spec" name="recurring_spec" value="weekly" /><br />
        be-weekly:<input type="radio" v-model="cEvent.recurring_spec" name="recurring_spec" value="be-weekly" /><br />
        monthly:<input type="radio" v-model="cEvent.recurring_spec" name="recurring_spec" value="monthly" /><br />
        <br />
        <input type="radio" v-model="cEvent.recurring_spec_number" name="recurring_spec_number" value=1 />1
        <input type="radio" v-model="cEvent.recurring_spec_number" name="recurring_spec_number" value=2 />2
        <input type="radio" v-model="cEvent.recurring_spec_number" name="recurring_spec_number" value=3 />3
        <input type="radio" v-model="cEvent.recurring_spec_number" name="recurring_spec_number" value=4 />4
        <br />
    </div>
    <button type="button" @click="AddEvent()">ADD</button>
    <button v-if="cEvent.user_id == userData.user_id" type="button" id="del_ev_btn" @click="EventRem(cEvent)">DELETE</button>
    <button type="button" @click="hideEventForm()">CANCEL</button>
    </form>
  </div>
<hr />


<hr />

<div id="prompt-form-container" >
    <form id="prompt-form">
      <div id="prompt-message">
          desc: {{cEvent.description}}<br />
          <br />
      </div>
      <input type="button" value="Ок" @click="hideModal($event)">
      <button type="button" id="del_ev_btn" @click="EventRem($event)">DELETE</button>
    </form>
  </div>

</div>


</template>

<script>
import $ from 'jquery';
import { constants } from 'os';
export default {
  name: 'calendar',
  data () {
			return{
            monthEventsList: [
              {
              date: new Date(),
              start: 'start date',
              end: 'end date',
              description: 'This is 1 test',
              recorent: 'no',
              room_id: 1
              },
            ],
            url:'http://tc.geeksforless.net/~user11/test/Client/api/',
            //url:'http://127.0.0.1/test/Client/api/',
            //url:'http://192.168.0.8/test/Client/api/',
            weekM:['M','T','W','T','F','S','S'],
            weekS:['S','M','T','W','T','F','S'],
            list: '',
            recurring:false,
            switcher: '',
            weekStart: localStorage.getItem('weekStart') || 6, // 6 - from mondey, 0 - from sand
            //token: localStorage.getItem('token') || '',
            //email: localStorage.getItem('email') || '',
						filterDate: undefined,
            selectedDate: new Date(),
            selDate: undefined,
            cEvent:{
              startH:     new Date().getHours(),
              startM:     new Date().getMinutes(),
              endH:       new Date().getHours(),
              endM:       new Date().getMinutes(),
              start_time: new Date(),
              end_time:   new Date(),
              recurring_spec_number:1,
              recurring_spec:'weekly',
              description: 'some description',
              booked_for:'times'
            },
						curMon:this.mnn(),
						curYear:this.yearnow(),
						currentMonthAndYear: this.getMonth(this.curMon)+' '+this.curYear,	
            currentMonthEventsList: {},
            descr: '',
            userData: JSON.parse(localStorage.getItem('uData')) || {
              token:'',
              email:'',
              boardroom: 1,
              logstat: 0,
              password: '',
              name:''
            },
			}

  },

  methods: {
  hideModal(e){
    $(document).find('#prompt-form-container').hide(500);
  },

  CurrEventClick(data){
    console.log(data);
    this.cEvent = data.e[0];
    $('#add_event_form').show(500);
  },

  showEventsDay: function(day) {
              var urll = this.url+'showEventsDay/';
              var userDataObj = {
                day: day,
                room_id:this.userData.boardroom,
                token: this.userData.token,
                email: this.userData.email,
                user_id: this.userData.user_id,
              };
              
              $.ajax({
                    url: urll,
                    type: 'PUT',
                    dataType: 'json',
                    data: userDataObj,
                    success: response => {
                        //result = $.parseJSON(response);
                        console.log(response);
                    },
                    error: function(response) { // Данные showEventsDay не отправлены
                        $('#result_form').html('Ошибка. Данные EvDay не отправлены.');
                    }
              });
              return false;
    },


    showEventsMonth: function(month) {
      console.log(this.userData.logstat);
      var $temp;
      console.log('---showEventsMonth--month-');
      console.log(month);
              var urll = this.url+'showEventsMonth/';
              var userDataObj = {
                day: month,
                room_id:this.userData.boardroom,
                token: this.userData.token,
                email: this.userData.email,
                user_id: this.userData.user_id
              };
              // console.log('---userDataObj---');
              // console.log(userDataObj);
              $.ajax({
                    url: urll,
                    type: 'PUT',
                    dataType: 'json',
                    data: userDataObj,
                    async: false,
                    success: response => {
                        //result = $.parseJSON(response);
                        
                        if (response.length < 1 || response == false)
                        {
                          console.log('не нашлось событий в базе');
                        } else {
                            $temp = response;
                            if (response.auth == 0){
                              this.userData.logstat = 0;
                              this.userData.token = '';
                            }
                            // console.log('---events response---');
                            // console.log(response);
                            
                        }
                    },
                    error: function(response) {
                        $('#result_form').html('Ошибка. Данные Month не отправлены.');
                    }
              });
              this.save();
              console.log('$temp');
              console.log($temp);
              this.monthEventsList = $temp;
              return $temp;
    },

  toTimestamp(strDate){
  var datum = Date.parse(strDate);
  return datum/1000;
  },

  toDate(t){
    return new Date(t);
  },

  hideEventForm(){
    $('#add_event_form').hide(500);
  },

  switchFirstDay() {
    var ch = this.switcher;
    if (!ch)
    {
      this.weekStart = 0;
    }else {
      this.weekStart = 6;
    }

    this.save();
  },

  save() {
    localStorage.setItem('uData', JSON.stringify(this.userData));
    localStorage.setItem('weekStart', this.weekStart || 6);
  },

  selectRoom(){
    //reserved
    this.userData.boardroom;
  },

	getMonth(n) {
	var monthsz =  ['Yan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Now','Dec'];
	return monthsz[n];
	},
	
	yearnow() {
		this.curYear = (new Date()).getFullYear();
		return (new Date()).getFullYear();
	},
	mnn() {
		this.curMon = (new Date()).getMonth();
		return (new Date()).getMonth();
	},
	
    previousMonth: function() {
    var tmpDate = this.selectedDate;
    var tmpMonth = tmpDate.getMonth() - 1;
	  this.selectedDate = new Date(tmpDate.setMonth(tmpMonth));
	  this.selectedDate.setMonth(tmpMonth);
	  this.currentMonthAndYear = this.getMonth(this.selectedDate.getMonth())+' '+this.selectedDate.getFullYear();
    },
	
    nextMonth: function() {
    var tmpDate = this.selectedDate;
    var tmpMonth = tmpDate.getMonth() + 1;
	  this.selectedDate = new Date(tmpDate.setMonth(tmpMonth));
	  this.currentMonthAndYear = this.getMonth(this.selectedDate.getMonth())+' '+this.selectedDate.getFullYear();
	},
	
  /////КЛИК ПО СОБЫТИЮ
    setDate: function(date) {
      if (date == this.filterDate) {
        this.filterDate = undefined;
        this.hideEventForm(date);
      } else {
        $('#add_event_form').show(500);
        var test = [];
        this.filterDate = date;
      }
    },
/////GET/////
    getTest: function() {
      this.$http.get(this.url)
      .then(response => {
        var res = JSON.stringify(response.data);
        this.list = JSON.parse(res || {});
        console.log(this.list.test);
      })
      .catch(error => {
        console.log(error);
      });
    },

    logout: function() {
              var urll = this.url+'Logout/';
              $.ajax({
                    url: urll,
                    type: 'PUT',
                    dataType: 'json',
                    data: this.userData,
                    success: response => {
                        //result = $.parseJSON(response);
                        //console.log(response);
                        if (response.loginstatus == 0)
                        {
                                this.userData.regstat = 0;
                                this.userData.token = '';
                                this.userData.name  =  '';
                                this.userData.logstat = 0;
                                this.save();
                        }
                    },
                    error: function(response) {
                        $('#result_form').html('Ошибка. Данные logout не отправлены.');
                    }
              });
              return false;
    },

/////check stat auth/////
    putIsAuth: function() {
      var d = {
        token: this.userData.token,
        email: this.userData.email,
      };
     $.ajax({
                    url:     this.url+'IsAuth/', 
                    type:     "put",
                    dataType: "html", 
                    data: d,  
                    success: response => { 
                        console.log('----isAuth----');
                        console.log(response);
                        var res = JSON.stringify(response);
                        this.list = res;
                        
                            if (res.auth == 1 || res.auth !== 'have_no_token'){
                                return 1;
                            }
                    },
                    error: function(response) { 
                    //console.log(response);
                        $('#result_form').html('Ошибка логина. Данные auth не отправлены.');
                    }
                });
                this.save();
    },

    ///// EVENT DELETE /////
    EventRem: function(e) {
    console.log('Event:');
    console.log();

                    var d = {
                      event_id: e.id,
                      room_id: this.userData.boardroom,
                      token: this.userData.token,
                      email: this.userData.email,
                      user_id: this.userData.user_id
                    };
    $.ajax({
                    url:     this.url+'EventRem/', 
                    type:     "DELETE", 
                    dataType: "html", 
                    data: d,  
                    success: response => { 
                        var result = $.parseJSON(response);
                        //var result = response;
                        console.log(response);
                        if (result.OK == 'deleted')
                        {
                          alert('Deleted');
                              setTimeout(function(){
                                window.location.reload();
                              }, 1000);
                        }
                        
                            //this.save();
                    },
                    error: function(response) { 
                    //console.log(response);
                        $('#result_form').html('Ошибка логина. Данные Rem не отправлены.');
                    }
                });


    },
	/////PUT LOGIN/////
    putLogin: function() {
                var d = $('.login_form').serialize();
                $.ajax({
                    url:     this.url+'Login/',
                    type:     "PUT", 
                    dataType: "html", 
                    data: d, 
                    async: false,
                    success: response => { 
                        var result = $.parseJSON(response);
                        //result = response;
                        console.log('Login:');
                        console.log(result);
                            if (result.loginstatus == 1){
                                $('#result_form').html('login: Успешно');
                                    this.userData.user_id = result.user_id;
                                    this.userData.email   = result.email;
                                    this.userData.token   = result.token;
                                    this.userData.name    = result.name;
                                    this.userData.logstat =  result.loginstatus;
                                    
                                    console.log('this.userData after login:');
                                    console.log(this.userData);
                                    
                            }else{

                                    this.userData.token   = '';
                                    this.userData.name    = '';
                                    this.userData.ogstat  = 0;
                            }
                            
                    },
                    error: function(response) {
                    //console.log(response);
                        $('#result_form').html('Ошибка логина. Данные Login не отправлены.');
                    }
                });
                this.save();
    },

    ////REGISTRATION ////
    registration(url) {
                    $.ajax({

                        url:      this.url+'Reg',
                        type:     "POST",
                        dataType: "html",
                        data: $("#"+'registration_form').serialize(),  // Сеарилизуем объект

                        success: response => { //Данные отправлены успешно

                            var result = $.parseJSON(response);
                            console.log('Reg:');
                            console.log(response);
                            //var result = response
                            //console.log(result);
                            $('#result_form').html('registration: '+result.regstatus);
                            if (result.regstatus == 'OK')
                            {
                              this.userData.regstat = 1;
                              this.userData.logstat = 1;
                              this.userData.email   = result.email;
                              alert('Registration OK');
                            }

                        },

                        error: function(response) {
                            $('#result_form').html('Ошибка. Данные Reg не отправлены.');
                        }

                    });
							
			},
/////   ADD EVENT  /////
    AddEvent: function(params) {
      var sending_event_form = $('#add_event_form').serialize()+'&name='+this.userData.name+'&token='+this.userData.token+'&user_id='+this.userData.user_id+'&room_id='+this.userData.boardroom+'&test=test';

            $.ajax({
                        url:      this.url+'addEvent',
                        type:     "put", 
                        dataType: "html", 
                        data: sending_event_form,
                        success: response => { 

                            //var result = $.parseJSON(response);
                            var result = response  //debag
                            console.log('AddEvent:');
                            console.log(result);
                            if (result.Error !== undefined){
                              alert(result.Error);
                            }else{
                              alert('OK Has been added!');
                              // setTimeout(function(){
                              //   window.location.reload();
                              // }, 500);
                            }
                            $('#result_form').html('registration: '+result.regstatus);
                        },

                        error: function(response) { 
                            $('#result_form').html('Ошибка. Данные Add не отправлены.');
                        }

                    });

      return false;
    },

  ////Get current ivent
  getCurrentEvent() {   
                        var $dataEvent = [];
                        return false;
                        return $dataEvent;
                    },

    isActive: function(date) {
      return date === this.filterDate;
    },
  
	  isWeekend: function(date) {
      if (this.weekStart == 6){
        return ((date.getDay() == 0) || (date.getDay() == 6));
        
      } 
        return ((date.getDay() == 5) || (date.getDay() == 6));
    },
	
    //фомируем месяц от входящей даты
    getCalendarMatrix: function(date) {
      
      var calendarMatrix = [];
      var eventMatrix = [];
      var startDay = new Date(date.getFullYear(), date.getMonth(), 1);
      var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);

      if (this.weekStart == 6){
        this.weekStart = 6;
      }else{
        this.weekStart = 0;
      }
      // Modify the result of getDay so that we treat Monday = 0 instead of Sunday = 0
      var startDow = (startDay.getDay() + this.weekStart) % 7;
      var endDow = (lastDay.getDay() + 6) % 7;

      // If the month didn't start on a Monday, start from the last Monday of the previous month
      startDay.setDate(startDay.getDate() - startDow);

      // If the month didn't end on a Sunday, end on the following Sunday in the next month
      lastDay.setDate(lastDay.getDate() + (6 - endDow));

      this.MonthEventsList = this.showEventsMonth(date.getMonth()+1); //получим ивенты за месяц для комнаты
        console.log('this.MonthEventsList');
        console.log(this.MonthEventsList);
        
      var week = [];
      
      while (startDay <= lastDay) {
        var $event = [];

        var room = this.userData.boardroom;
       
       ///добавляем события к датЕ если есть в MonthEventsList
        if (this.userData.logstat == 1)
        if ( typeof this.MonthEventsList == 'object'  && this.MonthEventsList.length !== 0)
        {
          //console.log(startDay.getTime());
          this.monthEventsList.forEach(function(item, i, arr) {

            item.start_time = new Date(Date.parse(item.start_time));
            item.end_time = new Date(Date.parse(item.end_time));
            var d1 = new Date(Date.parse(item.start_time));
            var d2 = startDay;

            if (d1.getMonth() == d2.getMonth())
            if (item.room_id == room && d1.getDate() == d2.getDate()) {
              $event.push(item);
            }
          });
        }
        
        console.log();
        week.push({d:new Date(startDay),e: $event}); //пушим событие к дате
        if (week.length === 7) {
          // console.log('---week---');
          // console.log(week);
          calendarMatrix.push(week);
          week = [];
        }
        startDay.setDate(startDay.getDate() + 1)
      }
      // console.log('---calendarMatrix---');
      // console.log(calendarMatrix);
      return calendarMatrix;
    },
  },
  computed: {
    // получим месяц
    gridArray: function() {
      var grid = this.getCalendarMatrix(this.selectedDate);
      return grid;
    },
	
	  formattedDate: function() {
      this.selDate = this.filterDate;
      return this.filterDate.getDate() + '  '+
	  this.getMonth((this.filterDate.getMonth()+1)) + ' of ' +
		this.filterDate.getFullYear();
    },

	
  },

  watch: {
    userData: function (val) {
      this.save();
    },
  }

}


</script>


<style scoped>

.switch {
    width: 180px;
    height: 50px;
    position: relative;
}
.switch label {
    display: block;
    width: 100%;
    height: 100%;
    position: relative;
    background: #a5a39d;
    border-radius: 40px;
    box-shadow:
        inset 0 3px 8px 1px rgba(0,0,0,0.2),
        0 1px 0 rgba(255,255,255,0.5);
}
.switch label:after {
    content: "";
    position: absolute;
    z-index: -1;
    top: -8px; right: -8px; bottom: -8px; left: -8px;
    border-radius: inherit;
    background: #ccc; /* Fallback */
    background: linear-gradient(#f2f2f2, #ababab);
    box-shadow: 0 0 10px rgba(0,0,0,0.3),
        0 1px 1px rgba(0,0,0,0.25);
}
.switch label:before {
    content: "";
    position: absolute;
    z-index: -1;
    top: -18px; right: -18px; bottom: -18px; left: -18px;
    border-radius: inherit;
    background: #eee; /* Fallback */
    background: linear-gradient(#e5e7e6, #eee);
    box-shadow: 0 1px 0 rgba(255,255,255,0.5);
    -webkit-filter: blur(1px); /* Smooth trick */
    filter: blur(1px); /* Future-proof */
}
.switch label i {
    display: block;
    height: 100%;
    width: 60%;
    position: absolute;
    left: 0;
    top: 0;
    z-index: 2;
    border-radius: inherit;
    background: #b2ac9e; /* Fallback */
    background: linear-gradient(#f7f2f6, #b2ac9e);
    box-shadow:
        inset 0 1px 0 white,
        0 0 8px rgba(0,0,0,0.3),
        0 5px 5px rgba(0,0,0,0.2);
}
.switch label i:after {
    content: "";
    position: absolute;
    left: 15%;
    top: 25%;
    width: 70%;
    height: 50%;
    background: #d2cbc3; /* Fallback */
    background: linear-gradient(#cbc7bc, #d2cbc3);
    border-radius: inherit;
}
.switch label i:before {
    content: "MON";
    position: absolute;
    top: 50%;
    right: -50%;
    margin-top: -12px;
    color: #666; /* Fallback */
    color: rgba(0,0,0,0.4);
    font-style: normal;
    font-weight: bold;
    font-family: Helvetica, Arial, sans-serif;
    font-size: 24px;
    text-transform: uppercase;
    text-shadow: 0 1px 0 #bcb8ae, 0 -1px 0 #97958e;
}

.switch input:checked ~ label { /* Background */
    background: #9abb82;
}
 
.switch input:checked ~ label i { /* Toggle */
    left: auto;
    right: -1%;
}
 
.switch input:checked ~ label i:before { /* On/off */
    content: "SAN";
    right: 115%;
    color: #82a06a;
    text-shadow: 0 1px 0 #afcb9b, 0 -1px 0 #6b8659;
}

.right_elems {
  display:inline-block;
  position:absolute;
  top:140px;
  right:1px;
  padding-bottom:0px;
  background:linear-gradient(rgba(185, 181, 173, 0.8),rgba(100,110,100,.8));
  border:1px solid green;
  border-radius:3px;
  padding:5px;
  margin-top:15px;
  margin:0 auto;
  
}


.login,.form_user_registration{
  color:#fff;
  text-shadow: 0 0 4px #000;
  font-family:'Times New Roman', Times, serif;
  width:170px;
  top:200px;
  right:10px;
  border:1px solid gray;
  border-radius:3px;
  padding:0 2px;
  float:left;
  background:rgba(0,0,0,.2);
  margin: auto;
  box-shadow:0px -1px 9px #000;
}

.login input,.form_user_registration input{
  border-radius: 8px;
  width: 170px;
  background:rgb(10,110,255);
  color:rgb(159, 162, 163);
  text-shadow:0 -1px 1px#800;
  font-family:monospace;
  font-weight: 600;
  border:none;
  box-shadow: -1px 0 0 0,1px 0 0 0;
}
.login button, .form_user_registration button{
  border-radius: 8px;
  width: 170px;
  background:linear-gradient(#fff,#999);
  color:#000;
  font-weight: 600;
  border:none;
  box-shadow: -1px 0 0 0,1px 0 0 0;
  margin-top: 5px;
  cursor:pointer;
}
.login button:hover, .form_user_registration button:hover{
  background:rgb(250, 200, 0);
}

.rms {
  position:absolute;
  top:470px;
  right:4px;
  background:linear-gradient(rgba(0,0,0,.3),rgba(0,0,0,.7));
  width:180px;
  color:#fff;
  border:1px solid gray;
  border-radius:3px;
  float:right;
  text-align:left;
  box-shadow:2px 2px 6px #000;
}
.table-bordered{
background:linear-gradient(#000,#888,#000);
box-shadow:2px 3px 7px #888;
border-radius:4px;
width:800px;
}

.red {
background:linear-gradient(#222,#555,#333);
color:#fff;
}
.red a{color:#fff;}

.fade-enter-active,
.fade-leave-active {
  transition: opacity .5s
}

.fade-enter,
.fade-leave-active {
  opacity: .3
  
}

.thead-default a {
  background:linear-gradient(#eee);
  border-radius:13px;
  box-shadow:1px 1px 7px 3px #fff;
  color:#000;
}
.thead-default{
  background:linear-gradient(#000,#fff,#fff,#fff);
  color:#000;
}
.tbody-default{
  background:linear-gradient(#ccc);
}

.tbody-default td{
  height:70px;
  max-height:80px;
  width:100px;
  }

.tbody-default td b{
  border:1px solid #aaa;
  width:100px;
  margin:0;
  cursor:pointer;
  padding: 0 35px;
  }

a {
  padding: 0px 10px 0px 10px;
}

.center-title {
  text-align: center;

}

.cal-selected,
.cal-selected:focus {
  background-color: rgba(0,0,0,.3);
  color: #fff;
  border-radius: 2px;
  border:1px solid red;
  font-weight: bold;
  box-shadow:2px 2px 4px #000;
  /*font-size: 1.8em*/
}
.nocurrmonth a {
color:#aaa;
text-decoration:none;
}
.event_time{
  border: 1px solid #00f;
  background:#08f;
  color:#fff;
  border-radius:4px;
  margin-top:5px;
  width: 100px;
  text-decoration:none;
  margin:2px auto;
  width:100px;
  max-width:110px;
  cursor:pointer;
}
#add_event_form {
  display:none;
}
.login_status{
  position:fixed;
  color:#fff;
  top:2px;
  left:2px;
  width:300px;
  height:50px;
  border-radius: 5px;
  background:rgb(28, 88, 28);
  box-shadow:0 0 4px black;
  cursor:pointer;
}
.logout_status{
  position:fixed;
  color:#fff;
  top:2px;
  left:2px;
  width:300px;
  height:50px;
  border-radius: 5px;
  background:red;
  box-shadow:0 0 4px black;
}
.hidden_elem {
  display:none;
  visibility: hidden;
  
}
#prompt-form {
      display: inline-block;
      padding: 5px 5px 5px 70px;
      width: 200px;
      border: 1px solid black;
      background: white url(https://js.cx/clipart/prompt.png) no-repeat left 5px;
      vertical-align: middle;
    }

    #prompt-form-container {
      position: fixed;
      display:none;
      top: 0;
      left: 0;
      z-index: 9999;
      width: 100%;
      height: 100%;
      text-align: center;
    }

    #prompt-form-container:before {
      display: inline-block;
      height: 100%;
      content: '';
      vertical-align: middle;
    }

    #prompt-form input[name="text"] {
      display: block;
      margin: 5px;
      width: 180px;
    }
    
    .sending_event {
      position: absolute;
      top:15px;
      padding-bottom:10px;
      margin: 15px 200px;
      background:linear-gradient(rgba(0,0,0,.5),rgba(0,0,0,.8));
      color:#fff;
      font-size:14px;
      border:1px solid #000;
      border-radius:4px;
      box-shadow:2px 2px 3px #bbb;
      width: 400px;
    }
    .sending_event * {
      background:#ccc;
      color:#000;
      border:none;
      font-size:12px;
      border-radius:3px;
    }

</style>
