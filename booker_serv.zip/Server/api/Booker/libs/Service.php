<?PHP
///////////////////////////
//MODEL EVENTS            /
/////////////////////////// 

include ('DB.php');
include ('Users.php');
class Service extends Users
{
    protected $dbObj;
    protected $pdo;

    function __construct()
    {
        $this->db = new DB;
        $this->pdo = DB::connect();
    }
    
    
    function getHelp($id = false)
    {
        $res = get_class_methods($this);
        return $res;
    }

    function emlValid($email)
    {
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return true;
        } else {
            return false;
        }
    }

    function deleteEventRem($params)
    {
        //check the token
        $aut['auth'] = 0;
        if (isset($params['token']))
        {
            $res = $this->putisAuth($params);

            if (isset($res['auth']) && $res['auth'] == 1)
                $aut['auth'] = $res['auth'];

        } else {
            $aut['auth'] = 0;
        }

        if ($aut['auth'] == 0)
            return ['Error'=>'not autorize asses'];
    
        $id = $params['event_id'];
        $user_id = $params['user_id'];
        $user_role = $params['role'];
        $room_id = $params['room_id'];

        if($this->admin($user_id))
        {
            $q = "delete from b_events where room_id = $room_id AND id=$id";
            $stmt = $this->pdo->prepare($q);
            $stmt->execute();
            $res = $stmt->fetchAll();
            return ['OK'=>'Admin delete event'];
        }

        if ($id !== $user_id)
            return ['Error'=>'event for another user'];

        $q = "SELECT count(id) FROM b_events WHERE " . 
        " room_id=" . $room_id . 
        " AND (user_id=$user_id AND $id=id)";
        
        $res = 'none';
        if (is_object($this->pdo))
        {
            $stmt = $this->pdo->prepare($q);
            $stmt->execute();
            $res = $stmt->fetchAll();
        }
        else
        {
            return ['Error'=>'failed connect DB'];
        }
        
        if (is_array($res))
        {   
            if ($res[0]['count(id)'] > 0)
            {
                $q = "delete from b_events where room_id = $room_id AND (id=$id and user_id=$user_id)";
                $stmt = $this->pdo->prepare($q);
                $stmt->execute();

                if ($stmt)
                    return ['OK'=>'deleted'];
            }
            else
            {
                return ['Error'=>'Event not exists'];
            }
        } 
        else
        {
            return ['Error'=>$res];
        }
        
    }

    function putEventEdit($params)
    {
        //return ['EditTest'=>$params]; //debug

        //check the token
        $aut['auth'] = 0;
        if (isset($params['token']))
        {
            $res = $this->putisAuth($params);

            if (isset($res['auth']) && $res['auth'] == 1)
                $aut['auth'] = $res['auth'];

        } else {
            $aut['auth'] = 0;
        }

        if ($aut['auth'] == 0)
            return ['Error'=>'not autorize asses'];

        $user_id = $params['uid'];
        $user_role = $params['role'];

        //DATA TIMEs
        if (!is_numeric($params['years']) && !(4 == strlen($params['years'])) )
            return ['Error'=>'no hourses_start or hourses_end'];

        // new wars to update from user form
        $event_id = $params['event_id'];
        $event_user_id = $params['event_user_id'];
        $room_id = $params['room_id'];
        $description = $this->strValid($params['description']);
        $year = $params['years'];
        $mon = $params['monthes'];
        $day = $params['day'];
        $hrStart = $params['hourses_start'];
        $minStart = $params['minutes_start'];
        $hrEnd = $params['hourses_end'];
        $minEnd = $params['minutes_end'];
        $selectedUser = $params['selectedUser']; //for replase
        //prepare update datas vars
        date_default_timezone_set('UTC');

        $d = new DateTime("$day-$mon-$year $hrStart:$minStart:00");
        $startTimeStamp = $d->format('Y-m-d H:i:s');

        $d = new DateTime("$day-$mon-$year $hrEnd:$minEnd:00");
        $endTimeStamp = $d->format('Y-m-d H:i:s');

        //the event time more then NOW time
        if (strtotime($startTimeStamp) <= strtotime($time))
            return ['Error'=>"selected start data($startTimeStamp) must to be more than NOW $time"];

        //astartt time more of end
        if($startTimeStamp >= $endTimeStamp)
            return ['Error'=>'start time more or eq then end time'];
        
        ///if admin, do update
        if($this->admin($user_id))
        {
            
            $res = $this->countIntervalEvent($startTimeStamp,$endTimeStamp,$room_id);
            

            if (($res > 0))
            {
                if ($res !== $event_id)
                    return ['Error'=>'busy time' . "$res =  $event_id"];
            }

            $q = "UPDATE b_events SET " . 
            "description=:d, start_time=:s, user_id=:u, " . 
            "end_time=:e " . 
            "WHERE id=:eid";
            
            $stmt = $this->pdo->prepare($q);
            $stmt->bindParam(':e',      $endTimeStamp, PDO::PARAM_STR);
            $stmt->bindParam(':eid',    $event_id, PDO::PARAM_INT);
            $stmt->bindParam(':s',      $startTimeStamp, PDO::PARAM_STR);
            $stmt->bindParam(':u',      $selectedUser, PDO::PARAM_INT);
            $stmt->bindParam(':d',      $description, PDO::PARAM_STR);
            $stmt->execute();

            if ($stmt)
                return ['OK'=>'updated by admin'];
            
            return ['OK'=>'admin default'];

        }

        $res = $this->countIntervalEvent($startTimeStamp,$endTimeStamp,$room_id);
        if ($res > 0 )
            return ['Error'=>'busy time'];

        //if the event have THE user id
        $q = "SELECT id from b_events where id=$id and user_id=$user_id";
        $stmt = $this->pdo->prepare($q);
        $stmt->execute();
        $res = $stmt->fetchAll();
        //update event
        if ($res[0]['id'] == $user_id)
            $q = "UPDATE `b_events` SET `start_time`=:s `end_time`=:e where `id`=:i and `user_id`=:u";
        $stmt = $this->pdo->prepare($q);
        $stmt->bindParam(':e', $endTimeStamp);
        $stmt->bindParam(':s', $startTimeStamp);
        $stmt->bindParam(':u', $user_id);
        $stmt->bindParam(':i', $id);
        $stmt->execute();

        if ($stmt)
            return ['OK'=>'updated'];
       

        
    }


    function countIntervalEvent($startTimeStamp,$endTimeStamp,$room_id)
    {
        $q = "select id from b_events WHERE " . 
            " (('$startTimeStamp' >= start_time and '$startTimeStamp' <= end_time) AND" .
            " ('$endTimeStamp' >= start_time and '$endTimeStamp' <= end_time)) AND " . 
            " $room_id = room_id";

        if (is_object($this->pdo))
        {
            $stmt = $this->pdo->prepare($q);
            $stmt->execute();
            $res = $stmt->fetchAll();
        }

        if (0 == count($res[0]) )
        {
            return 0;
        } else {
            return $res[0]['id'];
        }
        
    }



    function putAddEvent($params)
    {
     
      //ch token
      $aut['auth'] = 0;
      if (isset($params['token']))
      {
          $res = $this->putisAuth($params);
          if (isset($res['auth']) && $res['auth'] == 1)
            $aut['auth'] = $res['auth'];

      } else {
          $aut['auth'] = 0;
      }

        if ($aut['auth'] == 0)
            return ['Error'=>'not autorize asses'];

        if (empty($params['user_id']) || empty($params['room_id']))
            return ['Error'=>'no user_id or room_id'];

        if (empty($params['description']))
            return ['Error'=>'no description'];

        if (empty($params['years']))
            return ['Error'=>'no  year'];

        if (empty($params['monthes']) || empty($params['datas']))
            return ['Error'=>'no month or day'];

        if (empty($params['hourses_start']) || empty($params['hourses_end']))
            return ['Error'=>'no hourses_start or hourses_end'];

        if (empty($params['minutes_start']))
            $params['minutes_start'] = 0;

        if (empty($params['minutes_end']))
            $params['minutes_end'] = 0;

        $token = $params['token'];
        $name = $params['name'];
        $user_id = $params['user_id'];
        $room_id = $params['room_id'];
        
        $desc = $this->strValid($params['description']);

        //DATA TIMEs
        if (!is_numeric($params['years']) && !(4 == strlen($params['years'])) )
            return ['Error'=>'no hourses_start or hourses_end'];
            
        $year = $params['years'];
        $mon = $params['monthes'];
        if (strlen($mon) == 1)
            $mon = '0'.$mon;

        $day = $params['datas'];
        if (strlen($day) == 1)
            $day = '0'.$day;

        $hrStart = $params['hourses_start'];
        $minStart = $params['minutes_start'];
        $hrEnd = $params['hourses_end'];
        $minEnd = $params['minutes_end'];
        date_default_timezone_set('UTC');
        //"$d $M $y $h:$m:$s $z"

        $d = new DateTime("$day-$mon-$year $hrStart:$minStart:00");
        //$t = strtotime($d->format('Y-m-d H:i:s'));
        $startTimeStamp = $d->format('Y-m-d H:i:s');

        $d = new DateTime("$day-$mon-$year $hrEnd:$minEnd:00");
        //$t = strtotime($d->format('Y-m-d H:i:s'));
        $endTimeStamp = $d->format('Y-m-d H:i:s');

        $time = new DateTime();
        $time = $time->format('Y-m-d H:i:s');
        //event time must to be more current datatime
        if (strtotime($startTimeStamp) <= strtotime($time))
            return ['Error'=>"selected start data($startTimeStamp) must to be more than NOW $time"];

        //no coment
        if($startTimeStamp >= $endTimeStamp)
            return ['Error'=>'start time more or eq then end time'];

        //find free time in interval. 0 - or event id
        $res = $this->countIntervalEvent($startTimeStamp,$endTimeStamp,$room_id);
        if ($res > 0 )
        {
            return ['Error'=>'busy time'];
        }
        
        if (0 !== $res)
            return ['Error'=>'U cant get this time coz it not empty'];

            //if it recurring
            $recurring = 0;
            
            if (isset($params['recurring']) && 'on' == $params['recurring'])
            {
                $recurring = 1;
                
                //if recurring_spec
                if (isset($params['recurring_spec']) && strlen($params['recurring_spec']) > 3 )
                {   
                    
                    $recurring_spec = $params['recurring_spec'];

                    //if recurring_spec count
                    $recNumb = 0;
                    if ( !empty($params['recurring_spec_number']) )
                        $recNumb = $params['recurring_spec_number'];

                    $recurent_id = 0;           /// 0 - Parent
                    $debug = '';
                    switch ($recurring_spec) {
                        case 'weekly':
                            //checking busy times of rec events
                            $r = [];  //array of    start/end times
                            $errorBusyTime = false;
                            for ($i = 1; $i <= $recNumb; $i++)
                            {
                                $tmp1 = new DateTime($startTimeStamp);
                                $tmp1 = $tmp1->modify('+' . $i . ' week');
                                $tmp1 = $tmp1->format('Y-m-d H:i:s');
                                $start = $tmp1;

                                $tmp1 = new DateTime($endTimeStamp);
                                $tmp1 = $tmp1->modify('+' . $i . ' week');
                                $tmp1 = $tmp1->format('Y-m-d H:i:s');
                                $end = $tmp1;

                                $a = $this->countIntervalEvent($start,$end,$room_id);

                                if ($a > 0)
                                {
                                    $errorBusyTime = true;
                                    return ['Error'=>'week:on or more ch events is busy time'];
                                }
                                //добавим время
                                $r[] = ['start'=> $start, 'end'=> $end];
                            }
                            //если время совпадает у добавляемых событий с существующими, то ошибка
                            if ($errorBusyTime)
                                return ['Error'=>'The time is busy for first event'];

                            //if no error adding rec events
                            if (!$errorBusyTime)
                            {
   
                                //add parent event
                                $q="INSERT INTO " .
                                "b_events(user_id,created,start_time,end_time,room_id,recurent_id,description,name) " .
                                "VALUES ($user_id,'$time','$startTimeStamp','$endTimeStamp',$room_id,$recurent_id,'$desc','test')";
                                $stmt = $this->pdo->prepare($q);
                                $stmt->execute();
                                $debug .='weekly:add par,';

                                // get last added id of parent
                                $lastId = $this->pdo->lastInsertId();

                                //add child events
                                foreach ($r as $v)
                                {
                                    $s = $v['start'];
                                    $e = $v['end'];
                                    $q="INSERT INTO " .
                                    "b_events(user_id,created,start_time,end_time,room_id,recurent_id,description,name) " .
                                    "VALUES ($user_id,'$time','$s','$e',$room_id,$lastId,'$desc','test')";
                                    $stmt = $this->pdo->prepare($q);
                                    $stmt->execute();
                                    $debug .='weekly:add ch,';
                                }
                                return ['WeekAddChArr'=>$r];
                            } 
                            else 
                            {
                                return ['Error'=>'one or more events busy timed'];
                            }
                            break;
                        case 'be-weekly':

                            $res = $this->countIntervalEvent($startTimeStamp,$endTimeStamp,$room_id);
                            if ($res > 0)
                                return ['Error'=>'the time is busy for event 0'];

                            // + 1 week
                            $tmp1 = new DateTime($startTimeStamp);
                            $tmp1 = $tmp1->modify('+' . 1 . ' week');
                            $tmp1 = $tmp1->format('Y-m-d H:i:s');
                            $start = $tmp1;
                            $tmp1 = new DateTime($endTimeStamp);
                            $tmp1 = $tmp1->modify('+' . 1 . ' week');
                            $tmp1 = $tmp1->format('Y-m-d H:i:s');
                            $end = $tmp1;

                            $res = $this->countIntervalEvent($start,$end,$room_id);
                            if ($res > 0)
                                return ['Error'=>'the time is busy for be-weekly event'];

                            //add parent event
                            $q="INSERT INTO " .
                            "b_events(user_id,created,start_time,end_time,room_id,recurent_id,description,name) " .
                            "VALUES ($user_id,'$time','$startTimeStamp','$endTimeStamp',$room_id,$recurent_id,'$desc','test')";
                            $stmt = $this->pdo->prepare($q);
                            $stmt->execute();
                            $debug .='be-weekly:add par,';
                            // get last added id of parent
                            $lastId = $this->pdo->lastInsertId();
                            
                            $q="INSERT INTO " .
                            "b_events(user_id,created,start_time,end_time,room_id,recurent_id,description,name) " .
                            "VALUES ($user_id,'$time','$start','$end',$room_id,$lastId,'$desc','test')";
                            $stmt = $this->pdo->prepare($q);
                            $stmt->execute();
                            $debug .="be-weekly:add ch $lastId,";
                            break;
                        case 'monthly':
                            //check the time of parent
                            $res = $this->countIntervalEvent($startTimeStamp,$endTimeStamp,$room_id);
                            if ($res > 0)
                                return ['Error'=>'the time is busy for patent event'];

                            //checking time  monthly
                            // + 4 week

                            $tmp1 = new DateTime($startTimeStamp);
                            $tmp1 = $tmp1->modify('+' . 1 . ' month');
                            // if (date("w", strtotime($tmp1->format('w m-d')) == 5)
                            // {

                            // }
                            
                            $tmp1 = $tmp1->format('Y-m-d H:i:s');
                            $start = $tmp1;

                            $tmp1 = new DateTime($endTimeStamp);
                            $tmp1 = $tmp1->modify('+' . 1 . ' month');
                            $tmp1 = $tmp1->format('Y-m-d H:i:s');
                            $end = $tmp1;

                            

                            //check if adding event not exists now
                            $res = $this->countIntervalEvent($start,$end,$room_id);
                            if ($res > 0)
                                return ['Error'=>'the time is busy for event monthly'];

                            //add parent
                            $q="INSERT INTO " .
                            "b_events(user_id,created,start_time,end_time,room_id,recurent_id,description,name) " .
                            "VALUES ($user_id,'$time','$startTimeStamp','$endTimeStamp',$room_id,$recurent_id,'$desc','test')";
                            
                            $stmt = $this->pdo->prepare($q);
                            $stmt->execute();
                            $debug .="monthly:add par,";
                            $recurent_id = $this->pdo->lastInsertId(); //get last added id
                            //add child event
                            $q="INSERT INTO " .
                            "b_events(user_id,created,start_time,end_time,room_id,recurent_id,description,name) " .
                            "VALUES ($user_id,'$time','$start','$end',$room_id,$recurent_id,'$desc','test')";
                            $stmt = $this->pdo->prepare($q);
                            $stmt->execute();
                            $debug .="monthly:add ch rec_id= $recurent_id,";

                            break;
                    }

                }
                else
                {
                    return ['Error'=>'select recurring_spec'];
                }
            }
            else
            {
                //if parent event only add parent event
                $recurent_id = -1;                          /// (-1) - Not recurent
                $q="INSERT INTO " .
                            "b_events(user_id,created,start_time,end_time,room_id,recurent_id,description,name) " .
                            "VALUES ($user_id,'$time','$startTimeStamp','$endTimeStamp',$room_id,$recurent_id,'$desc','test')";
                            $stmt = $this->pdo->prepare($q);
                            $stmt->execute();
                $debug .="no_rec:add ,";
            }
            return ['OK'=>'200'];
    }

    function getShowEventsDay($params)
    {
        $aut['auth'] = 0;
        //проверим токен
        if (isset($params['token']))
        {
            $res = $this->putisAuth($params);
            if (isset($res['auth']) && $res['auth'] == 1)
                $aut['auth'] = $res['auth'];

        } else {
            $aut['auth'] = 0;
        }

        if ($aut['auth'] == 0)
            return ['auth'=>0];

        $room_id = $params['room_id'];
        $start_time = $params['start_time'];
        $end_time = $params['end_time'];
        $user_id = $params['end_time'];

        $q = 'select * from (SELECT * FROM b_events WHERE room_id=' . $params['room_id'] . 
        " AND user_id=" . $user_id . ")  WHERE (('$startTimeStamp' >= start_time and '$startTimeStamp' <= end_time) AND" .
        " ('$endTimeStamp' >= start_time and '$endTimeStamp' <= end_time))";

        if (is_object($this->pdo))
        {
            $stmt = $this->pdo->prepare($q);
            $stmt->execute();
            $res = $stmt->fetchAll();
        }
        return $res[0];

    }

    //Gets all events (Month) from the database
    function putShowEventsMonth($params)
    {
        //return $params; ///debug
        $aut['auth'] = 0;
        //проверим токен
        if (isset($params['token']))
        {
            $res = $this->putisAuth($params);
            if (isset($res['auth']) && $res['auth'] == 1)
                $aut['auth'] = $res['auth'];

        } else {
            $aut['auth'] = 0;
        }

        if ($aut['auth'] == 0)
            return ['auth'=>0];

        $room = $params['room_id'];
        $q = "select * from b_events where ( " .
            "created > LAST_DAY(CURDATE()) + INTERVAL 1 DAY - INTERVAL 1 MONTH " .
            "and created < DATE_ADD(LAST_DAY(CURDATE()), INTERVAL 1 DAY) ) and room_id = $room";

        if (is_object($this->pdo))
        {
            $stmt = $this->pdo->prepare($q);
            $stmt->execute();
            $res = $stmt->fetchAll();
        }

        if (count($res) <1 )
            $res[0] = 0;

        return $res;

    }

    
}