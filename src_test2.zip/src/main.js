// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import calendar from './components/calendar'
import test from './components/test'
import Axios from 'axios'


Vue.prototype.$http = Axios

Vue.component('calendar', calendar)
Vue.component('test', test)
Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>',
  
})
