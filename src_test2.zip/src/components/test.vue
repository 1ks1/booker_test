<template>

  <div class="test">
  <h2><router-link to="/" exact>home</router-link> | USERS</h2>
  
  <hr />
  <b class="u-name">Hello {{userData.name}}</b>
  <!--
  <ul class="js-main-buttons">
  <li><button @click="getUsers()">Get Users</button></li>
  <li><button @click="createNewUser()">New Users</button></li>
  </ul>
  -->
    
      <div class="user-list" v-if="usersList.length > 0">
        <table>
          <tr>
            <th>id</th><th>status</th><th>name</th><th>lastname</th><th>email</th><th>role</th><th>action</th>
          </tr>
          <tr v-for="(item, index) in usersList" :key="index" :class="{'red':item.status == 0,'admin':item.role == 'admin'}">
            <td>{{item.id}}</td>
            <td>{{item.status}}</td>
            <td>{{item.name}}</td>
            <td>{{item.lastname}}</td>
            <td><a :href="'mailto:'+item.email">{{item.email}}</a></td>
            <td>{{item.role}}</td>
            <td>
              <button v-on:click="editUser(item)">EDIT</button>
              <button v-on:click="removeUser(item)">DEL</button>
            </td>
          </tr>
        </table>
      </div>

      <div v-else class="user-list">
        no data for users
      </div>

      <br />
      <div v-if="newUser.name !== undefined || newUser.creating" class="js_edit_user">
        <div>
            <input type="text" v-model="newUser.name" /> - name<br />
            <input type="text" v-model="newUser.lastname" /> - lastname<br />
            <input type="text" v-model="newUser.email" /> - email<br />
            <input type="text" v-model="newUser.password" /> - password<br />
            <input type="text" v-model="newUser.role" /> - role(admin/user)<br />
            <input type="text" v-model="newUser.status" /> - status(1/0)<br />
            <button v-if="newUser.creating"  @click="saveNewUser(newUser)">New</button>
            <button v-else @click="saveUser(newUser)">Update</button>
            <button @click="clearUser()">Cancel</button> 
        </div>
      </div>

      <div v-if="!!message" class="message">
        <span>
          {{message}}
        </span>
      </div>

  </div>

</template>

<script>
import $ from 'jquery';
import { constants } from 'os';
export default {
  name: 'test',

  data () {
    return {
      url:'http://tc.geeksforless.net/~user11/test/Client/api/',
      //url:'http://127.0.0.1/test/Client/api/',
      //url:'http://tc.geeksforless.net/~user10/REST/server/api',
      //url:'http://173.212.224.161/booking/server/api/events/Events',
      
      message:false,
      userData: JSON.parse(localStorage.getItem('uData')) || {
              token:'',
              email:'',
              boardroom: 1,
              logstat: 0,
              password: '',
              name:'',
              crossDomain: true,
            },
      usersList:'',
      editableUser:{},
      newUser:{
        email:'email@example.com',
        name:'Vasilij',
        lastname:'Pupkin',
        password:'12345678',
        status:'0',
        role:'user',
        creating: true
      },
      userData: JSON.parse(localStorage.getItem('uData')) || {}
    } 
  },

  mounted() {
    this.getUsers();
  },

  methods: {
    
    //editform
    clearUser() {
      this.newUser = {};
    },  

    createNewUser() {
      this.newUser.creating = true;
    },

    saveNewUser(user){
      var userDataObj = {
            token: this.userData.token,
            email: this.userData.email,
            user_name: user.name,
            user_lastname: user.lastname,
            user_email: user.email,
            user_password: user.password,
            user_role: user.role,
            user_status: user.status
      };

      $.ajax({
              url: this.url+'NewUser/',
              type: 'post',
              dataType: 'json',
              data: userDataObj,
              success: response => {
                  console.log(response);
                  this.newUser = response;
                  if (response.OK){
                    this.message = 'new user id '+response.user_id;
                  }
              },
              error: function(response) { 
                console.log('Err');
                console.log(response);
              }
      });

      this.getUsers();
    },

    saveUser(user) {

      var userDataObj = {
        token: this.userData.token,
        email: this.userData.email,
        uid: this.userData.user_id,
        user_id: user.id,
        user_name: user.name,
        user_lastname: user.lastname,
        user_email: user.email,
        user_password: user.password,
        user_role: user.role,
        user_status: user.status
      };

      $.ajax({
        url: this.url+'saveUser/',
        type: 'put',
        dataType: 'json',
        data: userDataObj,
        success: response => {
            //result = $.parseJSON(response);
            console.log(response);
            this.newUser = response;
        },
        error: function(response) { 
          console.log('Err');
          console.log(response);
        }
      });

      this.getUsers();
  },

  removeUser(item) {
        var userDataObj = {
          token:    this.userData.token,
          email:    this.userData.email,
          user_id:  item.id
        };
      
        $.ajax({
            url: this.url+'RemUser/',
            type: 'delete',
            dataType: 'json',
            data: userDataObj,

            success: response => {
                //result = $.parseJSON(response);
                console.log(response);
                this.newUser = {};
            },

            error: function(response) { 
              console.log('Err');
              console.log(response);
            }

        });

        this.getUsers();

  },

    editUser(item) {
        var userDataObj = {
          room_id:  this.userData.boardroom,
          token:    this.userData.token,
          email:    this.userData.email,
          user_id:  this.userData.user_id,
          editableUid:item.id,
        };
      
        $.ajax({
            url: this.url+'UserEdit/',
            type: 'POST',
            dataType: 'json',
            data: userDataObj,

            success: response => {
                //result = $.parseJSON(response);
                console.log(response);
                this.newUser = response;
 
            },

            error: function(response) { 
              console.log('Err');
              console.log(response);
            }

        });

        this.getUsers();
    },

    getUsers: function(){
      var userDataObj = {
          token:    this.userData.token,
          email:    this.userData.email,
          user_id:  this.userData.user_id,
        };
      
        $.ajax({

            url: this.url+'Users/',
            type: 'get',
            dataType: 'json',
            data: userDataObj,

            success: response => {
                //result = $.parseJSON(response);
                console.log(response);
                this.usersList = response;
            },

            error: function(response) { 
              console.log('Err');
              console.log(response);
            }
        });
      console.log(this.usersList);
      return false;
    },

  },

  computed: {

     isAdmin(){
        if (this.userData.role == 'admin') {
            return true;
          } else {
            return 1; //1 for debag (false)
        }         
    }

  },

}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.user-list table{
  margin:auto;
  border:1px solid gray;
  border-collapse: collapse;
  border-radius: 3px;
  background:linear-gradient(#ccc,#fff);
}
.user-list td{
  border: 1px solid black; 
}
.js_edit_user{
  text-align:left;
  width:500px;
  border:1px solid black;
  border-radius: 3px ;
  margin:auto;
  background:rgba(0,0,0,.5);
  color:#fff;
}

button{
  border:none;
  border-radius:3px;
  margin:5px 15px;
  box-shadow: 1px 1px 3px #000;
  cursor:pointer;
}
.red {
  background:red;
}
.admin {
  background:blue;
  color:#fff;
}
.admin a{
  text-decoration: none;
  background:blue;
  color:#fff;
  cursor:pointer;
}
.js-main-buttons ul{
  margin: 0; 
  padding: 4px;
}
.js-main-buttons li{
  display: inline;
  margin-right: 5px;
  border: 1px solid #000;
  border-radius: 3px ;
  padding: 3px;
}
</style>
