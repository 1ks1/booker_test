<template>
  <div class="homepage">
    <b>Home</b>
        <ul class="links">
            <li><router-link to="#" >home</router-link></li>
            <li><router-link to="test" >test</router-link></li>
            <li><a href="http://google.com">google</a></li>
        </ul>
    <div>

    <div class="user_info_find">
      <input type="text" v-model="userName" @keyup="getData" name="userName" id="userName" />
      <button @click="getData">Show response</button>
      <br />
      <input type="text" v-model="account_id" name="userId" id="userId" />
      <button @click="getUser">Show Info</button>
      <hr />
      нашлось: {{mcount}} максимум 100<br />
      <div v-for="(val,name) in this.list.data">
      <a href="#" @click="replName(val)">{{val.nickname}}</a>
      </div>
      <hr />
      userName:<b>{{userName}}</b> |
      account_id: <b>{{account_id}} </b><br />
      последний бой: <b>{{last_battle_time}}</b><br />
      вышел из игры: <b>{{logout_at}}</b><br />
        <div v-if="userInfo.account_id > 0">
          
          бои: <b>{{userInfo.statistics.all.battles}}</b><br />
          побед: <b>{{userInfo.statistics.all.wins/(userInfo.statistics.all.battles/100)}} %</b><br />
          опыт: <b>{{userInfo.statistics.all.xp}} </b><br />
          максимальный опыт за бой: <b>{{userInfo.statistics.all.max_xp}} </b><br />
          мксимальный урон за бой:<b>{{userInfo.statistics.all.max_damage}} </b><br />
          рейтинг: <b>{{userInfo.global_rating}} </b><br />
          попадания: <b>{{userInfo.statistics.all.hits_percents}}%</b><br />
          максимум фрагов: <b>{{userInfo.statistics.all.max_frags}} </b><br />
          прожил в игре: <b>{{years_in}}</b><br />
        </div>
      <hr />
      </div> 
        <ul class="info ">
          
          <table>
          <li v-for="(value, name) in userInfo">
                <div v-if=" typeof value == 'object' " class="red">
                    <div v-for="(value2, name2) in value ">
                        <div v-if=" typeof value2 == 'object' " class="green">
                              <div v-for="(value3, name3) in value2 ">
                                <div v-if=" typeof value3 == 'object' " class="blue">
                                  <div v-for="(value4, name4) in value3 ">
                                      <tr><td>{{name4}}</td><td> <b>{{value4}}</b></td></tr>
                                  </div>
                                </div>

                                <div v-else>
                                  <tr><td>{{name3}}</td><td> <b>{{value3}}</b></td></tr>
                                </div>

                              </div>
                        </div>

                        <div v-else>
                        <tr><td>{{name2}}</td><td> <b>{{value2}}</b></td></tr>
                        </div>

                    </div>
                </div>

              <div v-else>
                <tr><td>{{name}}</td><td> <b>{{value}}</b></td></tr>
              </div>
          </li>
          </table>

        </ul>
        <br />
        <ul class="players">
          <li v-for="(value, name) in playerList">
            {{name}}:{{value}}
          </li>
        </ul>
      <br />
      response:
      {{res}}
      <hr />
      response2:
      {{res2}}
    </div>
  </div>
</template>

<script>
export default {
  name: 'Home',
  data () {
    return {
      url: 'https://api.coindesk.com/v1/bpi/currentprice.json',
      url2: 'http://127.0.0.1/REST/client/api/help',
      url3: 'https://api.worldoftanks.ru/wot/account/list/?application_id=f900bd30e062527fe1a6847b07806e07',
      url4:'https://api.worldoftanks.ru/wot/account/info/?application_id=f900bd30e062527fe1a6847b07806e07&account_id=',
      res: '',
      res2: '',
      list: [],
      last_battle_time: 0,
      battles: 0,
      mcount: 0,
      eur: '',
      userName: '666__TAHKUCT__666',
      account_id:'79274938',
      logout_at:'',
      userInfo: [],
      playerList: [],
      years_in: 0
    }
  },
  methods: {
    getData(){
      this.$http.get(this.url3+'&search='+this.userName)
      .then(response => {
        this.res = JSON.stringify(response.data);
        this.list = JSON.parse(this.res || '[]');
        this.mcount = this.list.meta.count;
        if (this.mcount > 0)
        {
          this.account_id = this.list.data[0].account_id;
          this.playerList = this.list.data;

        } else {
          this.account_id = 0;
          this.playerList = {};
        }
        
        console.log(this.list);
        
      })
      .catch(error => {
        console.log(error);
      });

    },
    getUser(){
      this.$http.get(this.url4 + this.account_id)
      .then(response => {
        this.res2 = JSON.stringify(response.data);
        this.list2 = JSON.parse(this.res2 || '[]');
        this.userInfo = this.list2.data[this.account_id];
        this.last_battle_time = this.convert(this.userInfo.last_battle_time);
        var tmp = this.userInfo.last_battle_time - this.userInfo.created_at;
        this.to_years(tmp);
        this.pocent = this.userInfo.battles;
        this.logout_at = this.convert(this.userInfo.logout_at);
        console.log(this.userInfo.account_id);

        //console.log(this.userInfo);
      })
      .catch(error => {
        console.log(error);
      });

    },
    replName(val){
      this.userName = val.nickname;
      this.account_id = val.account_id;
      return false;
    },
      convert(stamp){
          // Unixtimestamp
          var unixtimestamp = stamp;
          // Months array
          var months_arr = ['Янв','Фев','Мар','Апр','Май','Июн','Июл','Авг','Сен','Окт','Ноя','Дек'];
          // Convert timestamp to milliseconds
          var date = new Date(unixtimestamp*1000);
          // Year
          var year = date.getFullYear();
          // Month
          var month = months_arr[date.getMonth()];
          // Day
          var day = date.getDate();
          // Hours
          var hours = date.getHours();
          // Minutes
          var minutes = "0" + date.getMinutes();
          // Seconds
          var seconds = "0" + date.getSeconds();
          // Display date time in MM-dd-yyyy h:m:s format
          //var convdataTime = day+'-'+month+'-'+year+' '+hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);
          var convdataTime = day+'.'+(1+date.getMonth())+'.'+year+' '+hours + ':' + minutes.substr(-2) + ':' + seconds.substr(-2);
          
          return convdataTime;
            
      },
      to_years(dif){
        if (dif <0){dif = dif*(-1)}
        var $hours = (dif/3600).toFixed();
        var $days = ($hours/24).toFixed();
        var $years = ($hours/365/24).toFixed();
        var $str = $years + ' (года)лет, ';
        var tmp = ($days - $years*365);
        $str = $str  +  tmp+' дней';
        this.years_in =  $str;
      }

  }
}
</script>

<style scoped>
.homepage {
  background: url("../assets/profile_bg.jpg") no-repeat fixed #1c1c1e;
  
  color:#b8b8a2;
  margin:0;
  padding:0;
}
b {
  color:#f9f5e1;
}
.red {
  color:red;
}
.green {
  color:rgb(126, 158, 126);
}
.blue {
  color:blue;
}
.user_info_find {
  text-align: left;
}

h1{
    margin:0;
    padding:0;
}
.links{
border:1px solid #00f;
background:rgba(200,200,200,.3);
}
.links li{
    display: inline-block;
    margin: 0 5px 5px 0;
    text-align: center;
    background:linear-gradient(rgb(226, 222, 222),rgb(4, 7, 6),#fff);
    cursor:pointer;
    border-radius: 4px;
}

.links li:hover{
    box-shadow:0 0 7px rgb(12, 20, 20);
}
.links li>a{
    margin:0;
    padding:0;
    display: block;
    padding: 5px 15px;
    color:#fff;
}
</style>