<?PHP
include ('libs/Service.php');

header('Cache-Control: no-cache');
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type,token, Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");
header('Access-Control-Allow-Methods: POST, GET, PUT, OPTIONS, DELETE, PATCH');
header("Access-Control-Max-Age: 3600");
header("Access-Control-Expose-Headers: Location");
      
class Shop 
{
    protected $action;
    protected $parameters;
    protected $service;
    protected $method;
    protected $viewType;
    protected $tmp;

    function __construct()
    {
        $this->method = $_SERVER['REQUEST_METHOD'];
        $this->viewType = $this->parseType($_SERVER['REQUEST_URI']);
        $this->service = new Service;
        $this->parameters = $this->parseParams($_SERVER['REQUEST_URI']);
    }

    function parseParams($url)
    {
        //$this->tmp = $_POST['type']; //debug
        $tmp = '';
        $params = [];
        //уберем все до "api/"
        $str = strtolower(preg_replace("/(.*?)api\//i", "", $url));
        $str = explode('/',$str);
        //забираем имя метода
        $this->action = array_shift ($str);
        //берем последний (значение) в ласт
        $last = array_pop($str);
        $params = $str;
        if (count($str) == 0)
        $params = [];
        
        //если есть ?
        if(strpos($last, '?') !== false)
        {
            //возмем левую часть от ?
            $params[] = explode('?',$last)[0];
            //запишем правую часть для разбора
            $tmp = explode('?',$last)[1];
        }
        
        //уберем расширение
        $info = pathinfo($tmp);
        if (isset($info['filename']))
        $tmp = $info['filename'];
        //разделим на переменные по амперсанд
        //print_r($tmp);
        $array = [];
        if(strpos($tmp, '&') !== false)
        {
            $array = explode('&',$tmp);//массив переменных
        } else {
            $array[] = $tmp;
        }
        $ar = '';
        foreach($array as $value)
        {
            $ar = explode('=',$value);
            if (empty($ar[1]))
            $ar[1] = '';
            $params[$ar[0]] = $ar[1];///добавляем параметры
        }

        if(strpos($tmp, '=') !== false)

        //добавим переменные в массив
        if (count($array) >= 1)
        foreach($array as $val)
        {
            $r = explode('=',$val);
            $k =  $r[0];
            $v =  $r[1];
            $params[$k] = $v;
        }
        
        $this->parameters = $params;
        return $params;
    }

    function parseType($url)
    {
        $viewType = 'json';
        if(strpos($url, strtolower('.txt')) !== false)
        $viewType = 'txt';
        if(strpos($url, strtolower('.html')) !== false)
        $viewType = 'html';
        if(strpos($url, strtolower('.xml')) !== false)
        $viewType = 'xml';
        return $viewType;
    }

    function validator($str)
    {
        $str = htmlspecialchars(trim($str));
        return $str;
    }

    function parseMethod()
    {
        $method = $this->method;
        $viewType = $this->viewType;
        $fName = $this->action;
        $fParams = $this->parameters;
        $res = '';
        if (count($fParams) == 0)
        $fParams = ['noparam'=>'noparam'];
        switch ($method) {
            case 'GET':
                    $res = $this->runAction('get' . $fName, $fParams);
                break;
            case 'POST':
                $fParams = $_POST;
                $res = $this->runAction('post' . $fName, $fParams);
                break;
            case 'PUT':
                parse_str(file_get_contents('php://input'), $params);
                $fParams = $params;
                $fName = $this->action;
                $res = $this->runAction('put' . $fName, $fParams);
                break;
            case 'DELETE':
                parse_str(file_get_contents('php://input'), $params);
                $fParams = $params;
                $res = $this->runAction('delete' . $fName, $fParams);
                break;
            default:
                return false;
        }

        $this->showRes($res, $viewType);
    }


    function runAction($fName, $params = false)
    {
        $r = false;
            if (method_exists($this->service, $fName))
            {
                $r = call_user_func([$this->service, $fName], $params);
            }  
        return $r;
    }

    private function showRes($result, $viewType = 'json')
    {
        // header('Access-Control-Allow-Origin: *');
        // header('Access-Control-Allow-Headers: *');
        // header('Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS');
        // header("Access-Control-Expose-Headers: Location");
        // header("Access-Control-Max-Age: 3600");

        header('Content-Type: text/html; charset=utf-8'); 
        
        if ($result === false)
        {
            header("HTTP/1.1 400 Bad Request Api");
            $result = ['400'=>'400 Bad Request Api Action!'];
        }else{
            header("HTTP/1.1 200 Ok");
        }

        if (empty($result))
        {
            header("HTTP/1.1 404 Any Not Found");
            $result = ['404'=>'Any Not Found'];
        }
        
        switch ($viewType) {
            case 'txt':
                header('Content-type: text/plain');
                echo '<pre>';
                print_r($result);
                echo '</pre>';
                break;
            case 'html':
                header('Content-type: text/html');
                if (is_array($result))
                {
                    foreach ($result as $v){echo $v . '<br />';}
                }else
                echo ($result);
                break;
            case 'xml':
                header('Content-type: application/xml');
                echo $this->toXml($result);
                break;
            default:
                header('Content-Type: application/json');
                //$result = ['tmp_show'=>$this->tmp]; ///DEBUG
                echo json_encode($result);
                break;
        }
    }

    function array_to_xml($array, &$xml) 
    {
        foreach($array as $key => $value) 
        {
            if(is_array($value)) 
            {
                if(!is_numeric($key))
                {
                    $subnode = $xml->addChild("$key");
                    $this->array_to_xml($value, $xml);
                } else {
                    $this->array_to_xml($value, $xml);
                }
            } else {
                $xml->addChild("$key","$value");
            }
        }
        return $xml;
    }

    private function toXml($data)
    {
        $xml = new SimpleXMLElement('<root/>');
        $node = $xml->addChild('Projects');
        $res = $this->array_to_xml($data, $node);
        return $res->asXML();
        
    }



}

$cl = new Shop();

$cl->parseMethod();

// echo "\n<pre>DEBUG INFO \n";
// echo 'REQUEST Method:';
// print_r($_SERVER['REQUEST_METHOD']);
// echo "\n";
// $arr = explode('/',$_SERVER['REQUEST_URI']);
// echo " \n";
// if (isset($arr[5]) && !empty($arr[5]))
// {
//     echo 'parameter 1: ' . $arr[5];
//     echo " \n";
// }
// echo " URL: \n";
// print_r($_SERVER['REQUEST_URI']);
// $data = [
// 'remote_host'=>$_SERVER['REMOTE_ADDR']
// ];
// $data ['url'] = explode('/',$_SERVER['REQUEST_URI']);
// echo json_encode($data);