<?PHP
///////////////////////////
//shop      methods///
/////////////////////////// 

include ('DB.php');
include ('Users.php');
class Service extends Users
{
    protected $dbObj;
    protected $pdo;

    function __construct()
    {
        $this->db = new DB;
        $this->pdo = DB::connect();
    }

    function getMd5($p = '')
	{
        if (is_array($p))
            $p = $p[0];
        if (strlen($p) < 1 || $p == 'Md5')
            return 'Please enter yo string';
        return md5($p);
	}
	
    function getHelp($id = false)
    {
        $res = get_class_methods($this);
        return $res;
    }

    function strValid($str)
    {
        $str = htmlspecialchars(trim($str));
        if (strlen($str)<1)
        return false;
        return $str;
    }

    function postOrderShow($params)
    {
      //return ['orderShowTest'=>$params];


      $email = '';
      $token = $params['token'];
      $email = $params['user_id'];

      //проверим токен
      if (isset($params['token']))
      {
          $res = $this->putisAuth(['token'=>$params['token']]);
          if (isset($res['auth']) && $res['auth'] == 1)
          $aut['auth'] = $res['auth'];
      } else {
          $aut['auth'] = 0;
      }

      if ($aut['auth'] == 0)
      return ['404'=>'asses denied'];

      //спросим ордер юзера
      $q = "SELECT cars.model model, cars.price price, orders.date date, orders.count 
      FROM cars, orders, users WHERE
      (users.id=orders.user_id AND orders.car_id=cars.id) AND users.email='$email'";

      if (is_object($this->pdo))
        {
            $stmt = $this->pdo->prepare($q);
            $stmt->execute();
            $res = $stmt->fetchAll();
        }

        if (is_array($res) && count($res) > 0)
        return $res;
        return ['Error'=>'302'];
    }
}