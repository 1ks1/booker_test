<?PHP 
include ('DB.php');
include ('Service.php');



print_r('asd');
