<?PHP
///////////////////////////
//MODEL USERS,login,reg,edit ...
///////////////////////////  

class Users
{
    function getMd5($p = '')
	{
        if (is_array($p))
            $p = $p[0];
        if (strlen($p) < 1 || $p == 'Md5')
            return 'Please enter yo string';
        return md5($p);
    }


    function putIsAuth($userData)
    {
        if (!isset($userData['token']) && strlen(trim($userData['token'])) < 5)
            return ['auth'=> 0];

        if (!isset($userData['email']) && strlen(trim($userData['email'])) < 5)
            return ['auth'=> 0];
            
        //ищем токен в базе
            $q      = "select count(email) from b_users " . 
                    "WHERE token='" . $userData['token'] . "'" . 
                    "and email='" . $userData['email'] . "'";

            if (is_object($this->pdo))
            {
                $stmt   = $this->pdo->prepare($q);
                $stmt->execute();
                $res    = $stmt->fetchAll();
            }
            else
            {
                return ['Error'=>' auth have no connect to database'];
            }
            
            if (is_array($res) && (1 == $res[0]['count(email)']))
            return ['auth'=>1];
            return ['auth'=>0];
    }

    function getCrypt($p = '')
	{
        if (is_array($p))
            $p = $p[0];
        if (strlen($p) < 1 || $p == 'Crypt')
            return 'Please enter yo string';
        $clearTextPassword = $p;
        // Encrypt password
        $password = crypt($clearTextPassword, base64_encode($clearTextPassword));
        return $password;
    }

    function strValid($str)
    {
        $str = trim($str);
        if (0 == strlen($str))
        return false;
        //delete double spaces
        $str = preg_replace('/\s{2,}/', ' ', $str);
        return $str;
    }

    function postReg($userData)
    {   

        
        $regstatus  = '';
        $token = md5(rand(1,10000)); //случайный токен
        //проверим что пришло
        if (!(isset($userData['email']) || 
            isset($userData['password']) ||
            isset($userData['confirmpassword']) ||
            isset($userData['firstname']) ||
            isset($userData['lastname'])))
            return ['regstatus'=>'fields empty'];

        if (strlen($userData['email']) < 5)
        return ['regstatus'=>'email error'];
        
        $eml    = $userData['email'];
        $p      = $userData['password'];
        $c      = $userData['confirmpassword'];
        $f      = $userData['firstname'];
        $l      = $userData['lastname'];
 
        //validate///   ////
        if ( (!$this->strValid($eml)) || (!$this->strValid($p)) || (!$this->strValid($c)) )
            return ['regstatus'=>'email || passwd not valid'];
        
        if ( (!$this->strValid($f)) || (!$this->strValid($l)) )
            return ['regstatus'=>'fname || lname not valid'];

        //совпадают ли пароли
        if ($p !== $c)
        return ['regstatus'=>'confirm password'];

        //ищем мыло в базе
        $q = 'select count(email) from b_users where email=' . "'$eml'";
        if (is_object($this->pdo))
        {
            $stmt   = $this->pdo->prepare($q);
            $stmt->execute();
            $res    = $stmt->fetchAll();
        }
        else
        {
            return ['Error'=>'have no connect to database'];
        }
        
        //если есть, говорим, что есть
        if (is_array($res) && $res[0]['count(email)'] > 0)
        {
            $regstatus = 'User exists!';
        } 
        else 
        {
            try
            {
                $ph = md5($p);
                //cоздадим токен 
                date_default_timezone_set('UTC');
                $d = new DateTime();
                $ts = $d->getTimestamp();
                $token = md5($eml . $p . $ts);
                $token = $this->getCrypt($token);

                //пишем юзера в базу
                $q = 'INSERT INTO b_users ' .
                "(name,lastname,email,password,token)" . 
                " values (:f,:l,:e,:p,'$token') ";
              
                $stmt = $this->pdo->prepare($q);
                $stmt->bindParam(':f', $f);
                $stmt->bindParam(':l', $l);
                $stmt->bindParam(':e', $eml);
                $stmt->bindParam(':p', $p);
                $stmt->execute();

                $regstatus='OK';
            }
            catch(PDOException $e) 
            {  
                //$result = 'Reg db error!' . $e->getMessage();
                $regstatus='Error' . $e->getMessage();
            }
            //$stmt->execute();
        }
        //отошлем клиенту статус
        return ['regstatus'=>$regstatus];
    }

    function putLogOut($userData)
    {
        //если не пришел емейл в ответ отсылаем логаут
        if (empty($userData['email']))
        return ['loginstatus'=>0,'token'=>'0'];
        
        $eml    = $userData['email'];
        $loginstatus = 0;
        $token = md5(rand(1,10000)); //случайный псевдо токен
        $q = "SELECT email from b_users WHERE email='$eml'";
                try
                {
                    $stmt = $this->pdo->prepare($q);
                    $stmt->execute();
                    $res = $stmt->fetchAll();
                    if (count($res) == 1)
                    {
                        //удалим токен юзера
                        $q     = "UPDATE b_users SET token = '$token' WHERE email = '$eml'";
                        $stmt = $this->pdo->prepare($q);
                        $stmt->execute();
                        
                    } else {
                        $loginstatus=0;
                    } 
                }
                catch(PDOException $e) 
                {  
                    $loginstatus='Error' . $e->getMessage();
                }
                $token = '__' + md5(rand(1,10000)); //случайный псевдо токен
        return ['loginstatus'=>$loginstatus,'token'=>$token];
    }



    function putLogin($userData)
    {

        if (empty($userData['email']))
        return ['loginstatus'=>'email is wrong'];

        if (empty($userData['password']))
        return ['loginstatus'=>'password is wrong'];

        if (strlen($userData['email']) < 5 || strlen($userData['password']) < 6)
        return ['loginstatus'=>'fields is too short'];
        
        $token = md5(rand(1,10000)); //случайный псевдо токен
        $name = '';
        $uid = '';
        $loginstatus = 0;

        $eml    = $userData['email'];
        $p      = $userData['password'];
        $ph     = md5($p);

        //проверим мыло и пароль
        $q      = 'SELECT id,name,email,password,role from b_users WHERE ' .
                "email='$eml' and password='$ph'";
                
            try
            {
                $stmt = $this->pdo->prepare($q);
                $stmt->execute();
                $res = $stmt->fetchAll();
                
                if (count($res)>0)
                {
                    $name   = $res[0]['name'];
                    $uid    = $res[0]['id'];
                    $role    = $res[0]['role'];
                    $loginstatus=1;
                } else {
                    $loginstatus='Wrong user or password';
                } 
            }
            catch(PDOException $e) 
            {  
                $loginstatus='Error' . $e->getMessage();
            }
            
            if ($loginstatus == 1)
            {
                //cоздадим токен 
                date_default_timezone_set('UTC');
                $d = new DateTime();
                $ts = $d->getTimestamp();
                $token = md5($eml . $p . $ts);
                $token = $this->getCrypt($token);
                //и запишем в базу
                 $q = "UPDATE b_users SET token = '$token' " .
                 "WHERE email = '$eml'";
                $stmt = $this->pdo->prepare($q);
                $stmt->execute();
            }
            //отошлем токен, мыло, имя и статус клиенту
        return ['loginstatus'=>$loginstatus,'email'=>$eml,'user_id'=>$uid,'name'=>$name,'token'=>$token,'role'=>$role];
    }

    function postUsers($params)
    {
        //проверим токен
        if (isset($params['token']))
        {
            $aut['auth'] = 0;
            $res = $this->putisAuth($params);
            if (isset($res['auth']) && $res['auth'] == 1)
            $aut['auth'] = $res['auth'];
        } else {
            $aut['auth'] = 0;
        }
        if ($aut['auth'] == 0)
        return ['Error'=>'not autorize asses'];
        ///закоментировано для дэбага
        // if is admin
        // $q="select role from b_users WHERE id=" . $params['user_id'] . 
        // " AND role='admin'"; 
        // $stmt = $this->pdo->prepare($q);
        // $stmt->execute();
        // $res = $stmt->fetchAll();
        // if (0 == count($res[0]))
        // return ['Error'=>'you are not admin'];

        $q="select * from b_users";
        $stmt = $this->pdo->prepare($q);
        $stmt->execute();
        $res = $stmt->fetchAll();
        return $res;

    }


    function putsaveUser ($params)
    {
        //проверим токен
        $aut['auth'] = 0;
        if (isset($params['token']))
        {
            $res = $this->putisAuth($params);
            if (isset($res['auth']) && $res['auth'] == 1)
            $aut['auth'] = $res['auth'];
        } else {
            $aut['auth'] = 0;
        }
        if ($aut['auth'] == 0)
        return ['Error'=>'not autorize asses'];

        if (empty($params['user_email']) ||
            empty($params['user_id']) )
        { return ['Error'=>'user_id || user_email']; }

        if (empty($params['user_lastname']) || 
        empty($params['user_name']) || 
        (! is_numeric($params['user_status'])) || 
        empty($params['user_password']) ||
        empty($params['user_role']) ) 
        { return ['Error'=>'user fields']; }
                            
        $name = $params['user_name'];
        $lastname = $params['user_lastname'];
        $role = $params['user_role'];
        $password = $params['user_password'];
        $email = $params['user_email'];
        $status = $params['user_status'];
        $uid = $params['user_id'];

        $q = "UPDATE b_users SET " . 
        " name =:n,lastname = :l,email = :e," . 
        "password = :p,role = :r,status = :s " . 
        "WHERE id=:u";

        $stmt = $this->pdo->prepare($q);

        $stmt->bindParam(':n', $name);
        $stmt->bindParam(':l', $lastname);
        $stmt->bindParam(':e', $email);
        $stmt->bindParam(':p', $password);
        $stmt->bindParam(':s', $status);
        $stmt->bindParam(':r', $role);
        $stmt->bindParam(':u', $uid);
   
        $stmt->execute();

        if (!$stmt) {return ['Error'=>"update user $uid false"];}
        return ['OK'=>'updated'];
    }
    
    function deleteRemUser($params)
    {
        //проверим токен
        $aut['auth'] = 0;
        if (isset($params['token']))
        {
            $res = $this->putisAuth($params);
            if (isset($res['auth']) && $res['auth'] == 1)
            $aut['auth'] = $res['auth'];
        } else {
            $aut['auth'] = 0;
        }
        if ($aut['auth'] == 0)
        return ['Error'=>'not autorize asses'];


        if ( empty($params['user_id']) ) 
        { return ['Error'=>'user fields']; }

        $uid = $params['user_id'];

        $q = "DELETE FROM `b_users` WHERE id=:u";
        $stmt = $this->pdo->prepare($q);
        $stmt->bindParam(':u', $uid);
        $stmt->execute();

        if (!$stmt) {return ['Error'=>"deleted user $uid false"];}
        return ['OK'=>"user $uid deleted"];
    }

    ///get user data for edit
    function postUserEdit($params)
    {
        //проверим токен
        $aut['auth'] = 0;
        if (isset($params['token']))
        {
            $res = $this->putisAuth($params);
            if (isset($res['auth']) && $res['auth'] == 1)
            $aut['auth'] = $res['auth'];
        } else {
            $aut['auth'] = 0;
        }
        if ($aut['auth'] == 0)
            return ['Error'=>'not autorize asses'];

        $uid = trim($params['editableUid']);
        if (! is_numeric($uid) && empty($uid))
            return ['Error'=>'User id error'];
        $q="select * from b_users WHERE id=" . $uid;
        $stmt = $this->pdo->prepare($q);
        $stmt->execute();
        $res = $stmt->fetchAll();
        return $res[0];
    }

    function postLogin($userData)
    {
        if (empty($userData['email']))
        return ['loginstatus'=>'email is wrong'];

        if (empty($userData['password']))
        return ['loginstatus'=>'password is wrong'];

        if (strlen($userData['email']) < 5 || strlen($userData['password']) < 6)
        return ['loginstatus'=>'fields is too short'];
        
        $token = md5(rand(1,10000)); //случайный псевдо токен
        $name = '';
        $uid = '';
        $loginstatus = 0;

        $eml    = $userData['email'];
        $p      = $userData['password'];
        $ph     = md5($p);

        //проверим мыло и пароль
        $q      = 'SELECT * from b_users WHERE ' .
                "email='$eml' and password='$ph'";
                
            try
            {
                $stmt = $this->pdo->prepare($q);
                $stmt->execute();
                $res = $stmt->fetchAll();
                
                if (count($res)>0)
                {
                    $status = $res[0]['status'];
                    $name   = $res[0]['name'];
                    $uid    = $res[0]['id'];
                    $loginstatus=1;
                } else {
                    $loginstatus='Wrong user or password';
                } 
            }
            catch(PDOException $e) 
            {  
                $loginstatus='Error' . $e->getMessage();
            }
            
            if ($loginstatus == 1)
            {
                //cоздадим токен 
                date_default_timezone_set('UTC');
                $d = new DateTime();
                $ts = $d->getTimestamp();
                $token = md5($eml . $p . $ts);
                $token = $this->getCrypt($token);
                //и запишем в базу
                 $q = "UPDATE b_users SET token = '$token' " .
                 "WHERE email = '$eml'";
                $stmt = $this->pdo->prepare($q);
                $stmt->execute();
            }
            //отошлем токен, мыло, имя и статус клиенту
        return ['loginstatus'=>$loginstatus,'email'=>$eml,'user_id'=>$uid,'name'=>$name,'token'=>$token, 'status'=>$status];
    }

    function postNewUser($params)
    {
        //проверим токен
        $aut['auth'] = 0;
        if (isset($params['token']))
        {
            $res = $this->putisAuth($params);
            if (isset($res['auth']) && $res['auth'] == 1)
            $aut['auth'] = $res['auth'];
        } else {
            $aut['auth'] = 0;
        }
        if ($aut['auth'] == 0)
        return ['Error'=>'not autorize asses'];

        if (empty($params['user_email']))
        { return ['Error'=>'user_email']; }
        

        if (empty($params['user_lastname']) || 
        empty($params['user_name']) || 
        (! is_numeric($params['user_status'])) || 
        empty($params['user_password']) ||
        empty($params['user_role']) ) 
        { return ['Error'=>'user fields']; }
  
        $name = trim($params['user_name']);
        $lastname = trim($params['user_lastname']);
        $email = mb_strtolower(trim($params['user_email']));
        $role = mb_strtolower (trim($params['user_role']));
        $status = trim($params['user_status']);
        $password = md5(trim($params['user_password']));
        
        if(! $this->strValid($name))
            return ['Error'=>'name not valid'];

        if(! $this->strValid($lastname))
            return ['Error'=>'lastname not valid'];

        if ($role !== 'admin' &&  $role !== 'user')
            return ['Error'=>'role'];

        if (! $this->emlValid($email))
            return ['Error'=>'email not valid'];

        if (! $this->strValid($status) && !is_numeric($status))
            return ['Error'=>'status 1 or 0'];

        $q = 'INSERT INTO b_users ' .
            "(name,lastname,email,password,role,status,token)" . 
            " values (:n,:l,:e,:p,:r,:s,'')";
        
        $stmt = $this->pdo->prepare($q);

        $stmt->bindParam(':n', $name);
        $stmt->bindParam(':l', $lastname);
        $stmt->bindParam(':e', $email);
        $stmt->bindParam(':p', $password);
        $stmt->bindParam(':s', $status);
        $stmt->bindParam(':r', $role);
   
        $stmt->execute();

        if (!$stmt) {return ['Error'=>"update user $uid false"];}
        return ['OK'=>true,'user_id'=>$uid];

    }


}